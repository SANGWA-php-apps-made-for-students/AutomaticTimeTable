<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                course_year
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_account.php">account</a>
<a href="new_account_category.php">account_category</a>
<a href="new_profile.php">profile</a>
<a href="new_image.php">image</a>
<a href="new_department.php">department</a>
<a href="new_years.php">years</a>
<a href="new_streams.php">streams</a>
<a href="new_student_reg.php">student_reg</a>
<a href="new_academic_year.php">academic_year</a>
<a href="new_course.php">course</a>
<a href="new_lecturer.php">lecturer</a>
<a href="new_lecturer_course.php">lecturer_course</a>
<a href="new_teaching_hour.php">teaching_hour</a>
<a href="new_teaching_day.php">teaching_day</a>
<a href="new_course_taking.php">course_taking</a>
<a href="new_room.php">room</a>
<a href="new_time_table.php">time_table</a>
<a href="new_student.php">student</a>
<a href="new_course_year.php">course_year</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
