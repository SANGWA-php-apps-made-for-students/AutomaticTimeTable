<?php

require_once 'Fpdf/fpdf.php';
require_once '../web_db/connection.php';
class PDF extends FPDF {

// Load data
    function LoadData() {
        // Read file lines

        $database=new dbconnection();
        $db = $database->openconnection();        $sql = "select * from course_taking  ";
   // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
        $this->Cell(120, 7,'HOUSE WORKERS MIS', 0, 0, 'L');
        $this->Cell(60, 7, 'DISTRICT: KICUKIRO', 0, 0, 'L');
        $this->Ln();
        $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
        $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');

        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(170, 7, 'course_taking REPORT ', 0, 0, 'C');

        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", '', 14);
// </editor-fold>

$this->Cell(30, 7, 'course_taking_id', 1, 0, 'L');$this->Cell(30, 7, 'time_table', 1, 0, 'L');$this->Cell(30, 7, 'is_techer_available', 1, 0, 'L');$this->Cell(30, 7, 'tot_student_available', 1, 0, 'L');$this->Cell(30, 7, 'description', 1, 0, 'L');$this->Cell(30, 7, 'entry_date', 1, 0, 'L');$this->Cell(30, 7, 'User', 1, 0, 'L');
 $this->Ln();
        foreach ($db->query($sql) as $row) {
$this->cell(30, 7, $row['course_taking_id'], 1, 0, 'L');
$this->cell(30, 7, $row['time_table'], 1, 0, 'L');
$this->cell(30, 7, $row['is_techer_available'], 1, 0, 'L');
$this->cell(30, 7, $row['tot_student_available'], 1, 0, 'L');
$this->cell(30, 7, $row['description'], 1, 0, 'L');
$this->cell(30, 7, $row['entry_date'], 1, 0, 'L');
$this->cell(30, 7, $row['User'], 1, 0, 'L');


 $this->Ln();
        }
    }
}

$pdf = new PDF();
$pdf->SetFont('Arial', '', 13);
$pdf->AddPage();
$pdf->LoadData();
$pdf->Output(); 
