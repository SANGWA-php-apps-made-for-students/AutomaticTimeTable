
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
`department_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`department_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `years`
--

CREATE TABLE IF NOT EXISTS `years` (
`years_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`years_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `streams`
--

CREATE TABLE IF NOT EXISTS `streams` (
`streams_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `year`     int(11)   

,PRIMARY KEY (`streams_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `student_reg`
--

CREATE TABLE IF NOT EXISTS `student_reg` (
`student_reg_id`     int(11) NOT NULL AUTO_INCREMENT 
,`approved`     VARCHAR(60) 
,`ac_year`     VARCHAR(60) 
, `stream`     int(11)   
, `student`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`student_reg_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `academic_year`
--

CREATE TABLE IF NOT EXISTS `academic_year` (
`academic_year_id`     int(11) NOT NULL AUTO_INCREMENT 
, `start_year`     int(11)   
,`end_year`     VARCHAR(60) 

,PRIMARY KEY (`academic_year_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
`course_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `no_credits`     int(11)   
,`code`     VARCHAR(60) 

,PRIMARY KEY (`course_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `lecturer`
--

CREATE TABLE IF NOT EXISTS `lecturer` (
`lecturer_id`     int(11) NOT NULL AUTO_INCREMENT 
,`edu_level`     VARCHAR(60) 
, `account`     int(11)   

,PRIMARY KEY (`lecturer_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `lecturer_course`
--

CREATE TABLE IF NOT EXISTS `lecturer_course` (
`lecturer_course_id`     int(11) NOT NULL AUTO_INCREMENT 
, `lecturer`     int(11)   
, `Course`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`lecturer_course_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `teaching_hour`
--

CREATE TABLE IF NOT EXISTS `teaching_hour` (
`teaching_hour_id`     int(11) NOT NULL AUTO_INCREMENT 
,`start_time`     VARCHAR(60) 
,`end_time`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`teaching_hour_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `teaching_day`
--

CREATE TABLE IF NOT EXISTS `teaching_day` (
`teaching_day_id`     int(11) NOT NULL AUTO_INCREMENT 
,`day`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`teaching_day_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `course_taking`
--

CREATE TABLE IF NOT EXISTS `course_taking` (
`course_taking_id`     int(11) NOT NULL AUTO_INCREMENT 
, `time_table`     int(11)   
,`is_techer_available`     VARCHAR(60) 
, `tot_student_available`     int(11)   
,`description`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`course_taking_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
`room_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`room_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `time_table`
--

CREATE TABLE IF NOT EXISTS `time_table` (
`time_table_id`     int(11) NOT NULL AUTO_INCREMENT 
, `teaching_hour`     int(11)   
, `teaching_day`     int(11)   
, `room`     int(11)   
, `academic_year`     int(11)   
, `course`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`time_table_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
`student_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
,`reg_number`     VARCHAR(60) 

,PRIMARY KEY (`student_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `course_year`
--

CREATE TABLE IF NOT EXISTS `course_year` (
`course_year_id`     int(11) NOT NULL AUTO_INCREMENT 
, `course`     int(11)   
, `year`     int(11)   

,PRIMARY KEY (`course_year_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

