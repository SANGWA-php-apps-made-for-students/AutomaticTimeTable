<?php

    class new_values {

        function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
                $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_account_category($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
                $stm->execute(array(':account_category_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
                $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_image($path) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into image values(:image_id, :path)");
                $stm->execute(array(':image_id' => 0, ':path' => $path
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_department($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into department values(:department_id, :name)");
                $stm->execute(array(':department_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_years($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into years values(:years_id, :name)");
                $stm->execute(array(':years_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_streams($name, $year) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into streams values(:streams_id, :name,  :year)");
                $stm->execute(array(':streams_id' => 0, ':name' => $name, ':year' => $year
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_student_reg($approved, $ac_year, $stream, $student, $entry_date, $User) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into student_reg values(:student_reg_id, :approved,  :ac_year,  :stream,  :student,  :entry_date,  :User)");
                $stm->execute(array(':student_reg_id' => 0, ':approved' => $approved, ':ac_year' => $ac_year, ':stream' => $stream, ':student' => $student, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_academic_year($start_year, $end_year) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into academic_year values(:academic_year_id, :start_year,  :end_year)");
                $stm->execute(array(':academic_year_id' => 0, ':start_year' => $start_year, ':end_year' => $end_year
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_course($name, $no_credits, $code) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into course values(:course_id, :name,  :no_credits,  :code)");
                $stm->execute(array(':course_id' => 0, ':name' => $name, ':no_credits' => $no_credits, ':code' => $code
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_lecturer($edu_level, $account) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into lecturer values(:lecturer_id, :edu_level,  :account)");
                $stm->execute(array(':lecturer_id' => 0, ':edu_level' => $edu_level, ':account' => $account
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_lecturer_course($lecturer, $Course, $entry_date, $User) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into lecturer_course values(:lecturer_course_id, :lecturer,  :Course,  :entry_date,  :User)");
                $stm->execute(array(':lecturer_course_id' => 0, ':lecturer' => $lecturer, ':Course' => $Course, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_teaching_hour($start_time, $end_time, $entry_date, $User) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into teaching_hour values(:teaching_hour_id, :start_time,  :end_time,  :entry_date,  :User)");
                $stm->execute(array(':teaching_hour_id' => 0, ':start_time' => $start_time, ':end_time' => $end_time, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_teaching_day($day, $entry_date, $User) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into teaching_day values(:teaching_day_id, :day,  :entry_date,  :User)");
                $stm->execute(array(':teaching_day_id' => 0, ':day' => $day, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_course_taking($time_table, $is_techer_available, $tot_student_available, $description, $entry_date, $User) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into course_taking values(:course_taking_id, :time_table,  :is_techer_available,  :tot_student_available,  :description,  :entry_date,  :User)");
                $stm->execute(array(':course_taking_id' => 0, ':time_table' => $time_table, ':is_techer_available' => $is_techer_available, ':tot_student_available' => $tot_student_available, ':description' => $description, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_room($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into room values(:room_id, :name)");
                $stm->execute(array(':room_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_time_table($teaching_hour, $teaching_day, $room, $academic_year, $course, $entry_date, $User) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into time_table values(:time_table_id, :teaching_hour,  :teaching_day,  :room,  :academic_year,  :course,  :entry_date,  :User)");
                $stm->execute(array(':time_table_id' => 0, ':teaching_hour' => $teaching_hour, ':teaching_day' => $teaching_day, ':room' => $room, ':academic_year' => $academic_year, ':course' => $course, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_student($account, $reg_number) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into student values(:student_id, :account,  :reg_number)");
                $stm->execute(array(':student_id' => 0, ':account' => $account, ':reg_number' => $reg_number
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_course_year($course, $year) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into course_year values(:course_year_id, :course,  :year)");
                $stm->execute(array(':course_year_id' => 0, ':course' => $course, ':year' => $year
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

    }
    