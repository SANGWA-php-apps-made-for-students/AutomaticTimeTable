<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image ,$profile_id ));

}
 function update_image( $path,$image_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
$stmt->execute(array($path ,$image_id ));

}
 function update_department( $name,$department_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE department set 
name= ? WHERE department_id=?");
$stmt->execute(array($name ,$department_id ));

}
 function update_years( $name,$years_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE years set 
name= ? WHERE years_id=?");
$stmt->execute(array($name ,$years_id ));

}
 function update_streams( $name, $year,$streams_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE streams set 
name= ?, year= ? WHERE streams_id=?");
$stmt->execute(array($name, $year ,$streams_id ));

}
 function update_student_reg( $approved, $ac_year, $stream, $student, $entry_date, $User,$student_reg_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE student_reg set 
approved= ?, ac_year= ?, stream= ?, student= ?, entry_date= ?, User= ? WHERE student_reg_id=?");
$stmt->execute(array($approved, $ac_year, $stream, $student, $entry_date, $User ,$student_reg_id ));

}
 function update_academic_year( $start_year, $end_year,$academic_year_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE academic_year set 
start_year= ?, end_year= ? WHERE academic_year_id=?");
$stmt->execute(array($start_year, $end_year ,$academic_year_id ));

}
 function update_course( $name, $no_credits, $code,$course_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE course set 
name= ?, no_credits= ?, code= ? WHERE course_id=?");
$stmt->execute(array($name, $no_credits, $code ,$course_id ));

}
 function update_lecturer( $edu_level, $account,$lecturer_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE lecturer set 
edu_level= ?, account= ? WHERE lecturer_id=?");
$stmt->execute(array($edu_level, $account ,$lecturer_id ));

}
 function update_lecturer_course( $lecturer, $Course, $entry_date, $User,$lecturer_course_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE lecturer_course set 
lecturer= ?, Course= ?, entry_date= ?, User= ? WHERE lecturer_course_id=?");
$stmt->execute(array($lecturer, $Course, $entry_date, $User ,$lecturer_course_id ));

}
 function update_teaching_hour( $start_time, $end_time, $entry_date, $User,$teaching_hour_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE teaching_hour set 
start_time= ?, end_time= ?, entry_date= ?, User= ? WHERE teaching_hour_id=?");
$stmt->execute(array($start_time, $end_time, $entry_date, $User ,$teaching_hour_id ));

}
 function update_teaching_day( $day, $entry_date, $User,$teaching_day_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE teaching_day set 
day= ?, entry_date= ?, User= ? WHERE teaching_day_id=?");
$stmt->execute(array($day, $entry_date, $User ,$teaching_day_id ));

}
 function update_course_taking( $time_table, $is_techer_available, $tot_student_available, $description, $entry_date, $User,$course_taking_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE course_taking set 
time_table= ?, is_techer_available= ?, tot_student_available= ?, description= ?, entry_date= ?, User= ? WHERE course_taking_id=?");
$stmt->execute(array($time_table, $is_techer_available, $tot_student_available, $description, $entry_date, $User ,$course_taking_id ));

}
 function update_room( $name,$room_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE room set 
name= ? WHERE room_id=?");
$stmt->execute(array($name ,$room_id ));

}
 function update_time_table( $teaching_hour, $teaching_day, $room, $academic_year, $course, $entry_date, $User,$time_table_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE time_table set 
teaching_hour= ?, teaching_day= ?, room= ?, academic_year= ?, course= ?, entry_date= ?, User= ? WHERE time_table_id=?");
$stmt->execute(array($teaching_hour, $teaching_day, $room, $academic_year, $course, $entry_date, $User ,$time_table_id ));

}
 function update_student( $account, $reg_number,$student_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE student set 
account= ?, reg_number= ? WHERE student_id=?");
$stmt->execute(array($account, $reg_number ,$student_id ));

}
 function update_course_year( $course, $year,$course_year_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE course_year set 
course= ?, year= ? WHERE course_year_id=?");
$stmt->execute(array($course, $year ,$course_year_id ));

}

}

