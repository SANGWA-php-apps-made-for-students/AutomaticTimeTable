//<editor-fold defaultstate="collapsed" desc="these variables are used in the delete and update of the table records">
var table_update = '';
var id_delete = 0;
var current_del_btn = null;
//</editor-fold>
$(document).ready(function () {
    get_new_data_hide_show();
    show_form_toUpdate();
    course_year_del_udpate();
    get_pages_moving();
    dlog_btn_No_Yes();
    hide_select_pane();
    show_Y_N_dialog();
    hide_Y_N_dialog();

    get_account_category_id_combo();
    get_profile_id_combo();
    get_image_id_combo();
    get_year_id_combo();
    get_stream_id_combo();
    get_student_id_combo();
    get_account_id_combo();
    get_lecturer_id_combo();
    get_Course_id_combo();
    get_time_table_id_combo();
    get_teaching_hour_id_combo();
    get_teaching_day_id_combo();
    get_room_id_combo();
    get_academic_year_id_combo();
    get_course_id_combo();
    get_account_id_combo();
    get_year_id_combo();


});

function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').val();
            $('#txt_account_category_id').val(cbo_account_category);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
            $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_image_id_combo() {
    try {
        $('.cbo_image').change(function () {
            var cbo_image = $('.cbo_image option:selected').val();
            $('#txt_image_id').val(cbo_image);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_year_id_combo() {
    try {
        $('.cbo_year').change(function () {
            var cbo_year = $('.cbo_year option:selected').val();
            $('#txt_year_id').val(cbo_year);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_stream_id_combo() {
    try {
        $('.cbo_stream').change(function () {
            var cbo_stream = $('.cbo_stream option:selected').val();
            $('#txt_stream_id').val(cbo_stream);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_student_id_combo() {
    try {
        $('.cbo_student').change(function () {
            var cbo_student = $('.cbo_student option:selected').val();
            $('#txt_student_id').val(cbo_student);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
            $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_lecturer_id_combo() {
    try {
        $('.cbo_lecturer').change(function () {
            var cbo_lecturer = $('.cbo_lecturer option:selected').val();
            $('#txt_lecturer_id').val(cbo_lecturer);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_Course_id_combo() {
    try {
        $('.cbo_Course').change(function () {
            var cbo_Course = $('.cbo_Course option:selected').val();
            $('#txt_Course_id').val(cbo_Course);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_time_table_id_combo() {
    try {
        $('.cbo_time_table').change(function () {
            var cbo_time_table = $('.cbo_time_table option:selected').val();
            $('#txt_time_table_id').val(cbo_time_table);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_teaching_hour_id_combo() {
    try {
        $('.cbo_teaching_hour').change(function () {
            var cbo_teaching_hour = $('.cbo_teaching_hour option:selected').val();
            $('#txt_teaching_hour_id').val(cbo_teaching_hour);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_teaching_day_id_combo() {
    try {
        $('.cbo_teaching_day').change(function () {
            var cbo_teaching_day = $('.cbo_teaching_day option:selected').val();
            $('#txt_teaching_day_id').val(cbo_teaching_day);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_room_id_combo() {
    try {
        $('.cbo_room').change(function () {
            var cbo_room = $('.cbo_room option:selected').val();
            $('#txt_room_id').val(cbo_room);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_academic_year_id_combo() {
    try {
        $('.cbo_academic_year').change(function () {
            var cbo_academic_year = $('.cbo_academic_year option:selected').val();
            $('#txt_academic_year_id').val(cbo_academic_year);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_course_id_combo() {
    try {
        $('.cbo_course').change(function () {
            var cbo_course = $('.cbo_course option:selected').val();
            $('#txt_course_id').val(cbo_course);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
            $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_course_id_combo() {
    try {
        $('.cbo_course').change(function () {
            
            var cbo_course = $(this,'option:selected').val();
            alert(cbo_course);
            $('#txt_course_id').val(cbo_course);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_year_id_combo() {
    try {
        $('.cbo_year').change(function () {
            var cbo_year = $('.cbo_year option:selected').val();
            $('#txt_year_id').val(cbo_year);
        });
    } catch (err) {
        alert(err.message);
    }
}
function cancel_update() {
    $('.cancel_btn').unbind('click').click(function () {
        var cancel_update = $(this).data('cancel_name');
        $.post('../admin/handler.php', {cancel_update: cancel_update}, function (data) {
        }).complete(function () {
            window.location.reload();
        });
    });
}
function hide_Y_N_dialog() {//here the user will be confirming to delete the record
    $('#user_yes_btn,  .yes_dlg_btn').click(function () {
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {

        }).complete(function () {
            $('.y_n_dialog').fadeOut(300);
            current_del_btn.closest('tr').slideUp(400);
            $('.menu').show();
            window.location.reload();
        });
    });
    $('#no_btn, .no_btn').click(function () {
        $('.y_n_dialog').fadeOut(300);
        $('.menu').show();
    });

}
function show_Y_N_dialog() {
    $('.y_n_dialog').fadeIn(200);
}
function get_new_data_hide_show() {
    $('.new_data_hider').click(function () {
        $('.new_data_box').slideToggle();
    });

}
function validate_numbers_textfields() {
    $('.only_numbers').keydown(function (e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                        // Allow: home, end, left, right, down, up
                                (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer', 'pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname = $('#txt_shall_expand_toUpdate').val();
    if (updname != '') {
        $('.new_data_box').delay(200).slideDown();
    }

}
function postDisplayData(call_dialog, div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}
function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
        alert('Declined!');
    });
}
function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}

//update from account ...

function account_del_udpate() {
    $('.account_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount.. 
    $('.account_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from account_category ...

function account_category_del_udpate() {
    $('.account_category_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account_category').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount_category.. 
    $('.account_category_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from profile ...

function profile_del_udpate() {
    $('.profile_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.profile').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprofile.. 
    $('.profile_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from image ...

function image_del_udpate() {
    $('.image_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.image').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimage.. 
    $('.image_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from department ...

function department_del_udpate() {
    $('.department_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.department').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdepartment.. 
    $('.department_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from years ...

function years_del_udpate() {
    $('.years_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.years').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromyears.. 
    $('.years_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from streams ...

function streams_del_udpate() {
    $('.streams_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.streams').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromstreams.. 
    $('.streams_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from student_reg ...

function student_reg_del_udpate() {
    $('.student_reg_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.student_reg').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromstudent_reg.. 
    $('.student_reg_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from academic_year ...

function academic_year_del_udpate() {
    $('.academic_year_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.academic_year').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromacademic_year.. 
    $('.academic_year_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from course ...

function course_del_udpate() {
    $('.course_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.course').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcourse.. 
    $('.course_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from lecturer ...

function lecturer_del_udpate() {
    $('.lecturer_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.lecturer').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromlecturer.. 
    $('.lecturer_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from lecturer_course ...

function lecturer_course_del_udpate() {
    $('.lecturer_course_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.lecturer_course').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromlecturer_course.. 
    $('.lecturer_course_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from teaching_hour ...

function teaching_hour_del_udpate() {
    $('.teaching_hour_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.teaching_hour').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromteaching_hour.. 
    $('.teaching_hour_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from teaching_day ...

function teaching_day_del_udpate() {
    $('.teaching_day_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.teaching_day').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromteaching_day.. 
    $('.teaching_day_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from course_taking ...

function course_taking_del_udpate() {
    $('.course_taking_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.course_taking').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcourse_taking.. 
    $('.course_taking_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from room ...

function room_del_udpate() {
    $('.room_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.room').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromroom.. 
    $('.room_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from time_table ...

function time_table_del_udpate() {
    $('.time_table_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.time_table').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromtime_table.. 
    $('.time_table_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from student ...

function student_del_udpate() {
    $('.student_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.student').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromstudent.. 
    $('.student_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}//update from course_year ...

function course_year_del_udpate() {
    $('.course_year_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.course_year').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcourse_year.. 
    $('.course_year_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}
