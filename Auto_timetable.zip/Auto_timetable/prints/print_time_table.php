<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines
            $year = 1;
            $database = new dbconnection();
            $db = $database->openconnection();

            $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
            $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');
            $this->Ln();


            //get years
            $year_sql = "select * from years";
            $year_stmt = $db->prepare($year_sql);
            $year_stmt->execute();
            while ($year_row = $year_stmt->fetch()) {

                $year = $year_row['years_id'];
                $sql = "SELECT years.years_id,academic_year.start_year ,academic_year.end_year, time_table.time_table_id,teaching_day.day as teaching_day,time_table.entry_date, teaching_hour.teaching_hour_id as teaching_hour, teaching_hour.start_time,teaching_hour.end_time,room.name as 'room',course.name as course, years.name as 'yearname',lecturer.lecturer_id,profile.name as prof_name, profile.last_name  from time_table 
                    join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour
                    join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day
                    join room on room.room_id=time_table.room 
                    join academic_year on academic_year.academic_year_id=time_table.academic_year 
                    join lecturer_course on lecturer_course.lecturer_course_id=time_table.course 
                    join account on account.account_id=time_table.User 
                    join profile on profile.profile_id=account.profile 
                    join course on lecturer_course.Course=course.course_id 
                    join lecturer on lecturer.lecturer_id= lecturer_course.lecturer
                    join course_year on course_year.course=course.course_id
                    join years on years.years_id=course_year.year                                                
                    WHERE years.years_id=:year 
                    group by time_table.time_table_id
                    order by teaching_day.teaching_day_id, teaching_hour.teaching_hour_id asc  ";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":year" => $year));
                // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
                $this->Cell(120, 7, 'AUTOMATIC  TIMETABLE', 0, 0, 'L');
                $this->Cell(60, 7, 'DISTRICT: KICUKIRO', 0, 0, 'L');
                $this->Ln();


                $this->SetFont("Arial", 'B', 14);
                $this->Ln();
                $this->Ln();
                $this->Cell(170, 7, 'TIMETABLE REPORT YEAR ' . $year, 0, 0, 'C');
                $this->Ln();
                $this->Ln();
                $this->SetFont("Arial", '', 10);
// </editor-fold>
//            $this->Cell(30, 7, 'time_table_id', 1, 0, 'L');
                $this->Cell(36, 7, 'Teaching_hour', 1, 0, 'L');
                $this->Cell(30, 7, 'Teaching_day', 1, 0, 'L');
                $this->Cell(30, 7, 'Day', 1, 0, 'L');
                $this->Cell(40, 7, 'Room', 1, 0, 'L');
                $this->Cell(30, 7, 'Ac. Year', 1, 0, 'L');
                $this->Cell(44, 7, 'Course', 1, 0, 'L');
                $this->Cell(40, 7, 'Lecturer', 1, 0, 'L');
                $this->Cell(30, 7, 'Entry date', 1, 0, 'L');
//            $this->Cell(30, 7, 'User', 1, 0, 'L');
                $this->Ln();
                while ($row = $stmt->fetch()) {
//                $this->cell(30, 7, $row['time_table_id'], 1, 0, 'L');
                    $this->cell(36, 7, $row['start_time'] . ' - ' . $row['end_time'], 1, 0, 'L');
                    $this->cell(30, 7, $row['teaching_day'], 1, 0, 'L');
                    $this->cell(30, 7, $row['teaching_day'], 1, 0, 'L');
                    $this->cell(40, 7, $row['room'], 1, 0, 'L');
                    $this->cell(30, 7, $row['start_year'] . ' - ' . $row['end_year'], 1, 0, 'L');
                    $this->cell(44, 7, $row['course'], 1, 0, 'L');
                    $this->cell(40, 7, $row['prof_name'] . ' ' . $row['last_name'], 1, 0, 'L');
                    $this->cell(30, 7, $row['entry_date'], 1, 0, 'L');
//                $this->cell(30, 7, $row['User'], 1, 0, 'L');
                    $this->Ln();
                }
                $this->addPage('L');
            }
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 10);
    $pdf->AddPage('L');
    $pdf->LoadData();
    $pdf->Output();
    