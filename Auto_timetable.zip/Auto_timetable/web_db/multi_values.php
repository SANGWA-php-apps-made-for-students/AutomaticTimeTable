<?php
    require_once '../web_db/connection.php';

    class multi_values {

        function list_account($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account </td>
                        <td> Patient </td><td> Patient </td><td> Patient </td><td> Patient </td><td> Patient </td><td> Patient </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_id']; ?>
                        </td>
                        <td class="account_category_id_cols account " title="account" >
                            <?php echo $this->_e($row['account_category']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_created']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['profile']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['password']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['is_online']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                               <?php echo $row['account_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_update_link" style="color: #000080;" value="
                               <?php echo $row['account_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_account_category($id) {

                $db = new dbconnection();
                $sql = "select   account.account_category from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['account_category'];
                echo $field;
            }

            function get_chosen_account_date_created($id) {

                $db = new dbconnection();
                $sql = "select   account.date_created from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_created'];
                echo $field;
            }

            function get_chosen_account_profile($id) {

                $db = new dbconnection();
                $sql = "select   account.profile from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['profile'];
                echo $field;
            }

            function get_chosen_account_username($id) {
                
                $db = new dbconnection();
                $sql = "select   account.username from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['username'];
                echo $field;
            }

            function get_chosen_account_password($id) {

                $db = new dbconnection();
                $sql = "select   account.password from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['password'];
                echo $field;
            }

            function get_chosen_account_is_online($id) {

                $db = new dbconnection();
                $sql = "select   account.is_online from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['is_online'];
                echo $field;
            }

            function All_account() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_id   from account";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function get_last_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function list_account_category($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account_category";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account_category </td>
                        <td> Patient </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_category_id']; ?>
                        </td>
                        <td class="name_id_cols account_category " title="account_category" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                               <?php echo $row['account_category_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_category_update_link" style="color: #000080;" value="
                               <?php echo $row['account_category_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_category_name($id) {

                $db = new dbconnection();
                $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_category_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_account_category() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_category_id   from account_category";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function get_last_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function list_profile($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from profile";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> profile </td>
                        <td> Patient </td><td> Patient </td><td> Patient </td><td> Patient </td><td> Patient </td><td> Patient </td><td> Patient </td><td> Patient </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['profile_id']; ?>
                        </td>
                        <td class="dob_id_cols profile " title="profile" >
                            <?php echo $this->_e($row['dob']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['gender']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['telephone_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['email']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['residence']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['image']); ?>
                        </td>


                        <td>
                            <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                               <?php echo $row['profile_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="profile_update_link" style="color: #000080;" value="
                               <?php echo $row['profile_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_profile_dob($id) {

                $db = new dbconnection();
                $sql = "select   profile.dob from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['dob'];
                echo $field;
            }

            function get_chosen_profile_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_profile_last_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['last_name'];
                echo $field;
            }

            function get_chosen_profile_gender($id) {

                $db = new dbconnection();
                $sql = "select   profile.gender from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['gender'];
                echo $field;
            }

            function get_chosen_profile_telephone_number($id) {

                $db = new dbconnection();
                $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['telephone_number'];
                echo $field;
            }

            function get_chosen_profile_email($id) {

                $db = new dbconnection();
                $sql = "select   profile.email from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['email'];
                echo $field;
            }

            function get_chosen_profile_residence($id) {

                $db = new dbconnection();
                $sql = "select   profile.residence from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['residence'];
                echo $field;
            }

            function get_chosen_profile_image($id) {

                $db = new dbconnection();
                $sql = "select   profile.image from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['image'];
                echo $field;
            }

            function All_profile() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  profile_id   from profile";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function get_last_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function list_image($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from image";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> image </td>
                        <td> Patient </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['image_id']; ?>
                        </td>
                        <td class="path_id_cols image " title="image" >
                            <?php echo $this->_e($row['path']); ?>
                        </td>


                        <td>
                            <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="image_id"  data-table="
                               <?php echo $row['image_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="image_update_link" style="color: #000080;" value="
                               <?php echo $row['image_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_image_path($id) {

                $db = new dbconnection();
                $sql = "select   image.path from image where image_id=:image_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':image_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['path'];
                echo $field;
            }

            function All_image() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  image_id   from image";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function get_last_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function list_department($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from department";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> department </td>
                        <td> Name </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['department_id']; ?>
                        </td>
                        <td class="name_id_cols department " title="department" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="department_delete_link" style="color: #000080;" data-id_delete="department_id"  data-table="
                               <?php echo $row['department_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="department_update_link" style="color: #000080;" value="
                               <?php echo $row['department_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_department_name($id) {

                $db = new dbconnection();
                $sql = "select   department.name from department where department_id=:department_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':department_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_department() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  department_id   from department";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_department() {
                $con = new dbconnection();
                $sql = "select department.department_id from department
                    order by department.department_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['department_id'];
                return $first_rec;
            }

            function get_last_department() {
                $con = new dbconnection();
                $sql = "select department.department_id from department
                    order by department.department_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['department_id'];
                return $first_rec;
            }

            function list_years($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from years";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> years </td>
                        <td> Name </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['years_id']; ?>
                        </td>
                        <td class="name_id_cols years " title="years" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="years_delete_link" style="color: #000080;" data-id_delete="years_id"  data-table="
                               <?php echo $row['years_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="years_update_link" style="color: #000080;" value="
                               <?php echo $row['years_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_years_name($id) {

                $db = new dbconnection();
                $sql = "select   years.name from years where years_id=:years_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':years_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_years() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  years_id   from years";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_years() {
                $con = new dbconnection();
                $sql = "select years.years_id from years
                    order by years.years_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['years_id'];
                return $first_rec;
            }

            function get_last_years() {
                $con = new dbconnection();
                $sql = "select years.years_id from years
                    order by years.years_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['years_id'];
                return $first_rec;
            }

            function list_streams($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from streams";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> streams </td>
                        <td> Name </td><td> Year </td>
                    </tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['streams_id']; ?>
                        </td>
                        <td class="name_id_cols streams " title="streams" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['year']); ?>
                        </td>


                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_streams_name($id) {

            $db = new dbconnection();
            $sql = "select   streams.name from streams where streams_id=:streams_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':streams_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_streams_year($id) {

            $db = new dbconnection();
            $sql = "select   streams.year from streams where streams_id=:streams_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':streams_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['year'];
            echo $field;
        }

        function All_streams() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  streams_id   from streams";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_streams() {
            $con = new dbconnection();
            $sql = "select streams.streams_id from streams
                    order by streams.streams_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['streams_id'];
            return $first_rec;
        }

        function get_last_streams() {
            $con = new dbconnection();
            $sql = "select streams.streams_id from streams
                    order by streams.streams_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['streams_id'];
            return $first_rec;
        }

        function list_student_reg($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from student_reg";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> student_reg </td>
                        <td> Approved </td><td> academic Year </td><td> Stream </td><td> Student </td><td> Entry Date </td><td> User </td>
                    </tr></thead>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['student_reg_id']; ?>
                        </td>
                        <td class="approved_id_cols student_reg " title="student_reg" >
                            <?php echo $this->_e($row['approved']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['ac_year']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['stream']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['student']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>
                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_student_reg_approved($id) {

            $db = new dbconnection();
            $sql = "select   student_reg.approved from student_reg where student_reg_id=:student_reg_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':student_reg_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['approved'];
            echo $field;
        }

        function get_chosen_student_reg_ac_year($id) {

            $db = new dbconnection();
            $sql = "select   student_reg.ac_year from student_reg where student_reg_id=:student_reg_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':student_reg_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['ac_year'];
            echo $field;
        }

        function get_chosen_student_reg_stream($id) {

            $db = new dbconnection();
            $sql = "select   student_reg.stream from student_reg where student_reg_id=:student_reg_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':student_reg_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['stream'];
            echo $field;
        }

        function get_chosen_student_reg_student($id) {

            $db = new dbconnection();
            $sql = "select   student_reg.student from student_reg where student_reg_id=:student_reg_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':student_reg_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['student'];
            echo $field;
        }

        function get_chosen_student_reg_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   student_reg.entry_date from student_reg where student_reg_id=:student_reg_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':student_reg_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_student_reg_User($id) {

            $db = new dbconnection();
            $sql = "select   student_reg.User from student_reg where student_reg_id=:student_reg_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':student_reg_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_student_reg() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  student_reg_id   from student_reg";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_student_reg() {
            $con = new dbconnection();
            $sql = "select student_reg.student_reg_id from student_reg
                    order by student_reg.student_reg_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['student_reg_id'];
            return $first_rec;
        }

        function get_last_student_reg() {
            $con = new dbconnection();
            $sql = "select student_reg.student_reg_id from student_reg
                    order by student_reg.student_reg_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['student_reg_id'];
            return $first_rec;
        }

        function list_academic_year($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from academic_year";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> academic_year </td>
                        <td> Start Year </td><td> End Year </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['academic_year_id']; ?>
                        </td>
                        <td class="start_year_id_cols academic_year " title="academic_year" >
                            <?php echo $this->_e($row['start_year']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['end_year']); ?>
                        </td>


                        <td>
                            <a href="#" class="academic_year_delete_link" style="color: #000080;" data-id_delete="academic_year_id"  data-table="
                               <?php echo $row['academic_year_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="academic_year_update_link" style="color: #000080;" value="
                               <?php echo $row['academic_year_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_academic_year_start_year($id) {

                $db = new dbconnection();
                $sql = "select   academic_year.start_year from academic_year where academic_year_id=:academic_year_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':academic_year_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['start_year'];
                echo $field;
            }

            function get_chosen_academic_year_end_year($id) {

                $db = new dbconnection();
                $sql = "select   academic_year.end_year from academic_year where academic_year_id=:academic_year_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':academic_year_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['end_year'];
                echo $field;
            }

            function All_academic_year() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  academic_year_id   from academic_year";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_academic_year() {
                $con = new dbconnection();
                $sql = "select academic_year.academic_year_id from academic_year
                    order by academic_year.academic_year_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['academic_year_id'];
                return $first_rec;
            }

            function get_last_academic_year() {
                $con = new dbconnection();
                $sql = "select academic_year.academic_year_id from academic_year
                    order by academic_year.academic_year_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['academic_year_id'];
                return $first_rec;
            }

            function list_course($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from course";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> course </td>
                        <td> Name </td><td> Number Of Credits </td><td> Code </td>
                    </tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['course_id']; ?>
                        </td>
                        <td class="name_id_cols course " title="course" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['no_credits']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['code']); ?>
                        </td>


                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_course_name($id) {

            $db = new dbconnection();
            $sql = "select   course.name from course where course_id=:course_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':course_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_course_no_credits($id) {

            $db = new dbconnection();
            $sql = "select   course.no_credits from course where course_id=:course_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':course_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['no_credits'];
            echo $field;
        }

        function get_chosen_course_code($id) {

            $db = new dbconnection();
            $sql = "select   course.code from course where course_id=:course_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':course_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['code'];
            echo $field;
        }

        function All_course() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  course_id   from course";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_course() {
            $con = new dbconnection();
            $sql = "select course.course_id from course
                    order by course.course_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['course_id'];
            return $first_rec;
        }

        function get_last_course() {
            $con = new dbconnection();
            $sql = "select course.course_id from course
                    order by course.course_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['course_id'];
            return $first_rec;
        }

        function list_lecturer($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "SELECT profile.name, profile.last_name, profile.gender,account.account_category,account.username,lecturer.edu_level from profile JOIN account on profile.profile_id = account.profile JOIN lecturer ON lecturer.account = account.account_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> lecturer First name </td>
                        <td> Lecturer Last name </td>
                        <td> Education level </td>
                        <td> User Name </td>
                    </tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['name']; ?>
                        </td>
                        <td class="edu_level_id_cols lecturer " title="lecturer" >
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['edu_level']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>

                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

        function list_hod() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select profile.profile_id, profile.name, profile.last_name, profile.gender,account.username from account "
                    . "join account_category on account_category.account_category_id=account.account_category "
                    . "join profile on profile.profile_id=account.profile "
                    . " "
                    . "where account_category.account_category_id=9";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> profile </td>

                        <td> Name </td>
                        <td> Last name </td>
                        <td> Gender </td>
                        <td> Username </td>
                        <td>Delete</td><td>Update</td></tr></thead>


                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['profile_id']; ?>
                        </td>

                        <td>
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['gender']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>




                        <td>
                            <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                               <?php echo $row['profile_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="profile_update_link" style="color: #000080;" value="
                               <?php echo $row['profile_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_lecturer_edu_level($id) {

                $db = new dbconnection();
                $sql = "select   lecturer.edu_level from lecturer where lecturer_id=:lecturer_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':lecturer_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['edu_level'];
                echo $field;
            }

            function get_chosen_lecturer_account($id) {

                $db = new dbconnection();
                $sql = "select   lecturer.account from lecturer where lecturer_id=:lecturer_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':lecturer_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['account'];
                echo $field;
            }

            function All_lecturer() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  lecturer_id   from lecturer";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_lecturer() {
                $con = new dbconnection();
                $sql = "select lecturer.lecturer_id from lecturer
                    order by lecturer.lecturer_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['lecturer_id'];
                return $first_rec;
            }

            function get_last_lecturer() {
                $con = new dbconnection();
                $sql = "select lecturer.lecturer_id from lecturer
                    order by lecturer.lecturer_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['lecturer_id'];
                return $first_rec;
            }

            function list_lecturer_course($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "SELECT profile.name, profile.last_name,lecturer.edu_level,course.name as 'coursename', course.code, course.no_credits from profile JOIN account on profile.profile_id = account.profile JOIN lecturer ON lecturer.account = account.account_id JOIN lecturer_course ON lecturer.lecturer_id = lecturer_course.lecturer JOIN course ON lecturer_course.Course = course.course_id  ";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> Lecturer First Name </td>
                        <td> Lecturer Last Name </td>
                        <td> Lecturer Level </td>
                        <td> Course Name </td>
                        <td> Course Code </td>
                        <td> Course Credits </td>
                    </tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['name']; ?>
                        </td>
                        <td class="lecturer_id_cols lecturer_course " title="lecturer_course" >
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['edu_level']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['coursename']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['code']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['no_credits']); ?>
                        </td>

                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

        function list_lecturer_course_lecdashboard($account) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "   SELECT profile.name, profile.last_name,lecturer.edu_level,course.name as 'coursename', course.code, course.no_credits "
                    . " from profile "
                    . " JOIN account on profile.profile_id = account.profile "
                    . " JOIN lecturer ON lecturer.account = account.account_id "
                    . " JOIN lecturer_course ON lecturer.lecturer_id = lecturer_course.lecturer "
                    . " JOIN course ON lecturer_course.Course = course.course_id  "
                    . " where account.account_id=:account ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":account" => $account));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> Lecturer First Name </td>
                        <td> Lecturer Last Name </td>
                        <td> Lecturer Level </td>
                        <td> Course Name </td>
                        <td> Course Code </td>
                        <td> Course Credits </td>
                    </tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['name']; ?>
                        </td>
                        <td class="lecturer_id_cols lecturer_course " title="lecturer_course" >
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['edu_level']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['coursename']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['code']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['no_credits']); ?>
                        </td>


                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_lecturer_course_lecturer($id) {

            $db = new dbconnection();
            $sql = "select   lecturer_course.lecturer from lecturer_course where lecturer_course_id=:lecturer_course_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':lecturer_course_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['lecturer'];
            echo $field;
        }

        function get_chosen_lecturer_course_Course($id) {

            $db = new dbconnection();
            $sql = "select   lecturer_course.Course from lecturer_course where lecturer_course_id=:lecturer_course_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':lecturer_course_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Course'];
            echo $field;
        }

        function get_chosen_lecturer_course_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   lecturer_course.entry_date from lecturer_course where lecturer_course_id=:lecturer_course_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':lecturer_course_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_lecturer_course_User($id) {

            $db = new dbconnection();
            $sql = "select   lecturer_course.User from lecturer_course where lecturer_course_id=:lecturer_course_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':lecturer_course_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_lecturer_course() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  lecturer_course_id   from lecturer_course";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_lecturer_course() {
            $con = new dbconnection();
            $sql = "select lecturer_course.lecturer_course_id from lecturer_course
                    order by lecturer_course.lecturer_course_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['lecturer_course_id'];
            return $first_rec;
        }

        function get_last_lecturer_course() {
            $con = new dbconnection();
            $sql = "select lecturer_course.lecturer_course_id from lecturer_course
                    order by lecturer_course.lecturer_course_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['lecturer_course_id'];
            return $first_rec;
        }

        function list_teaching_hour($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from teaching_hour";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> teaching_hour </td>
                        <td> Start Time </td><td> End Time </td><td> Entry Date </td><td> User </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['teaching_hour_id']; ?>
                        </td>
                        <td class="start_time_id_cols teaching_hour " title="teaching_hour" >
                            <?php echo $this->_e($row['start_time']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['end_time']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>


                        <td>
                            <a href="#" class="teaching_hour_delete_link" style="color: #000080;" data-id_delete="teaching_hour_id"  data-table="
                               <?php echo $row['teaching_hour_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="teaching_hour_update_link" style="color: #000080;" value="
                               <?php echo $row['teaching_hour_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_teaching_hour_start_time($id) {

                $db = new dbconnection();
                $sql = "select   teaching_hour.start_time from teaching_hour where teaching_hour_id=:teaching_hour_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':teaching_hour_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['start_time'];
                echo $field;
            }

            function get_chosen_teaching_hour_end_time($id) {

                $db = new dbconnection();
                $sql = "select   teaching_hour.end_time from teaching_hour where teaching_hour_id=:teaching_hour_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':teaching_hour_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['end_time'];
                echo $field;
            }

            function get_chosen_teaching_hour_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   teaching_hour.entry_date from teaching_hour where teaching_hour_id=:teaching_hour_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':teaching_hour_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_teaching_hour_User($id) {

                $db = new dbconnection();
                $sql = "select   teaching_hour.User from teaching_hour where teaching_hour_id=:teaching_hour_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':teaching_hour_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_teaching_hour() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  teaching_hour_id   from teaching_hour";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_teaching_hour() {
                $con = new dbconnection();
                $sql = "select teaching_hour.teaching_hour_id from teaching_hour
                    order by teaching_hour.teaching_hour_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['teaching_hour_id'];
                return $first_rec;
            }

            function get_last_teaching_hour() {
                $con = new dbconnection();
                $sql = "select teaching_hour.teaching_hour_id from teaching_hour
                    order by teaching_hour.teaching_hour_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['teaching_hour_id'];
                return $first_rec;
            }

            function list_teaching_day($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from teaching_day";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> teaching_day </td>
                        <td> Teaching Day </td><td> Entry Date </td><td> User </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['teaching_day_id']; ?>
                        </td>
                        <td class="day_id_cols teaching_day " title="teaching_day" >
                            <?php echo $this->_e($row['day']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>


                        <td>
                            <a href="#" class="teaching_day_delete_link" style="color: #000080;" data-id_delete="teaching_day_id"  data-table="
                               <?php echo $row['teaching_day_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="teaching_day_update_link" style="color: #000080;" value="
                               <?php echo $row['teaching_day_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

            function get_if_day_exists($day) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select teaching_day_id from teaching_day "
                        . " where day=:day";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":day" => $day));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['teaching_day_id'];
                return $first_rec;
            }

//chosen individual field
            function get_chosen_teaching_day_day($id) {

                $db = new dbconnection();
                $sql = "select   teaching_day.day from teaching_day where teaching_day_id=:teaching_day_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':teaching_day_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['day'];
                echo $field;
            }

            function get_chosen_teaching_day_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   teaching_day.entry_date from teaching_day where teaching_day_id=:teaching_day_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':teaching_day_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_teaching_day_User($id) {

                $db = new dbconnection();
                $sql = "select   teaching_day.User from teaching_day where teaching_day_id=:teaching_day_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':teaching_day_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_teaching_day() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  teaching_day_id   from teaching_day";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_teaching_day() {
                $con = new dbconnection();
                $sql = "select teaching_day.teaching_day_id from teaching_day
                    order by teaching_day.teaching_day_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['teaching_day_id'];
                return $first_rec;
            }

            function get_last_teaching_day() {
                $con = new dbconnection();
                $sql = "select teaching_day.teaching_day_id from teaching_day
                    order by teaching_day.teaching_day_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['teaching_day_id'];
                return $first_rec;
            }

            function list_course_taking($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from course_taking";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> course_taking </td>
                        <td> Time Table </td><td> Is Teacher Available </td><td> Total_students_avaiiable </td><td> Description </td><td> Entry Date </td><td> User </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['course_taking_id']; ?>
                        </td>
                        <td class="time_table_id_cols course_taking " title="course_taking" >
                            <?php echo $this->_e($row['time_table']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['is_techer_available']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['tot_student_available']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['description']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>


                        <td>
                            <a href="#" class="course_taking_delete_link" style="color: #000080;" data-id_delete="course_taking_id"  data-table="
                               <?php echo $row['course_taking_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="course_taking_update_link" style="color: #000080;" value="
                               <?php echo $row['course_taking_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_course_taking_time_table($id) {

                $db = new dbconnection();
                $sql = "select   course_taking.time_table from course_taking where course_taking_id=:course_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':course_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['time_table'];
                echo $field;
            }

            function get_chosen_course_taking_is_techer_available($id) {

                $db = new dbconnection();
                $sql = "select   course_taking.is_techer_available from course_taking where course_taking_id=:course_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':course_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['is_techer_available'];
                echo $field;
            }

            function get_chosen_course_taking_tot_student_available($id) {

                $db = new dbconnection();
                $sql = "select   course_taking.tot_student_available from course_taking where course_taking_id=:course_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':course_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['tot_student_available'];
                echo $field;
            }

            function get_chosen_course_taking_description($id) {

                $db = new dbconnection();
                $sql = "select   course_taking.description from course_taking where course_taking_id=:course_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':course_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['description'];
                echo $field;
            }

            function get_chosen_course_taking_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   course_taking.entry_date from course_taking where course_taking_id=:course_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':course_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_course_taking_User($id) {

                $db = new dbconnection();
                $sql = "select   course_taking.User from course_taking where course_taking_id=:course_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':course_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_course_taking() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  course_taking_id   from course_taking";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_course_taking() {
                $con = new dbconnection();
                $sql = "select course_taking.course_taking_id from course_taking
                    order by course_taking.course_taking_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['course_taking_id'];
                return $first_rec;
            }

            function get_last_course_taking() {
                $con = new dbconnection();
                $sql = "select course_taking.course_taking_id from course_taking
                    order by course_taking.course_taking_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['course_taking_id'];
                return $first_rec;
            }

            function list_room($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from room";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> room </td>
                        <td> Name </td>
                    </tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['room_id']; ?>
                        </td>
                        <td class="name_id_cols room " title="room" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_room_name($id) {

            $db = new dbconnection();
            $sql = "select   room.name from room where room_id=:room_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':room_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_room() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  room_id   from room";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_room() {
            $con = new dbconnection();
            $sql = "select room.room_id from room
                    order by room.room_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['room_id'];
            return $first_rec;
        }

        function get_last_room() {
            $con = new dbconnection();
            $sql = "select room.room_id from room
                    order by room.room_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['room_id'];
            return $first_rec;
        }

        function list_course_year() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from course_year  "
                    . " join course on course_year.course=course.course_id "
                    . " ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> course </td>
                        <td> Year </td>

                    </tr></thead>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 
                        <td class="course_id_cols course_year " title="course_year" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e('Year ' . $row['year']); ?>
                        </td>
                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

        function list_newtime_table() {
            if ($_SESSION['cat'] == 'hod') {
                ?>
                <table class="dataList_table timetable_view">

                    <tr><td>
                            YEAR 1
                            <table class="dataList_table timetable_view">
                                <tr><td>DAY</td>
                                    <td>HOUR</td>
                                    <td>START HOUR</td>
                                    <td>END HOUR</td>
                                    <td>ROOM</td>
                                    <td>LECTURER First name</td>
                                    <td>LECTURER Last name</td>

                                    <td>COURSE</td>
                                </tr>
                                <?php
                                $database = new dbconnection();
                                $db = $database->openConnection();
                                if (true) {//lecturer
                                }
                                $sql = " SELECT time_table.time_table_id,teaching_day.day, teaching_hour.teaching_hour_id, teaching_hour.start_time,teaching_hour.end_time,room.name as 'roomname',course.name, years.name as 'yearname',lecturer.lecturer_id,profile.name as 'teachername', profile.last_name as 'tlastname' from time_table join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day join room on room.room_id-time_table.room join academic_year on academic_year.academic_year_id=time_table.academic_year join lecturer_course on lecturer_course.lecturer_course_id=time_table.course join lecturer on lecturer_course.lecturer=lecturer.lecturer_id JOIN account on account.account_id=time_table.User join profile on profile.profile_id=account.profile join course on lecturer_course.Course=course.course_id join course_year on course_year.course=course.course_id join years on years.years_id=course_year.year WHERE years.name='Year 1' GROUP BY time_table.time_table_id";

                                $st = $db->prepare($sql);
                                $st->execute();
                                ?>

                                <?php
                                $pages = 1;
                                while ($row = $st->fetch()) {
                                    ?> 
                                    <tr>
                                        <td> <?php echo $row['day']; ?></td>
                                        <td><?php echo $row['teaching_hour_id']; ?></td>
                                        <td><?php echo $row['start_time']; ?></td>
                                        <td><?php echo $row['end_time']; ?></td>
                                        <td><?php echo $row['roomname']; ?></td>
                                        <td><?php echo $row['teachername']; ?></td>
                                        <td><?php echo $row['tlastname']; ?></td>

                                        <td><?php echo $row['name']; ?></td>
                                    </tr>
                                    <?php
                                    $pages += 1;
                                }
                                ?>
                            </table></td>


                    </tr>
                    <tr><td>
                            YEAR 2

                            <table class="dataList_table timetable_view">
                                <tr><td>DAY</td>
                                    <td>HOUR</td>
                                    <td>START HOUR</td>
                                    <td>END HOUR</td>
                                    <td>ROOM</td>
                                    <td>LECTURER First name</td>
                                    <td>LECTURER Last name</td>

                                    <td>COURSE</td>
                                </tr>
                                <?php
                                $database = new dbconnection();
                                $db = $database->openConnection();
                                $sql = " SELECT time_table.time_table_id,teaching_day.day, teaching_hour.teaching_hour_id, teaching_hour.start_time,teaching_hour.end_time,room.name as 'roomname',course.name, years.name as 'yearname',lecturer.lecturer_id,profile.name as 'teachername', profile.last_name as 'tlastname' from time_table join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day join room on room.room_id-time_table.room join academic_year on academic_year.academic_year_id=time_table.academic_year join lecturer_course on lecturer_course.lecturer_course_id=time_table.course join lecturer on lecturer_course.lecturer=lecturer.lecturer_id JOIN account on account.account_id=time_table.User join profile on profile.profile_id=account.profile join course on lecturer_course.Course=course.course_id join course_year on course_year.course=course.course_id join years on years.years_id=course_year.year WHERE years.name='Year 2' GROUP BY time_table.time_table_id";

                                $st = $db->prepare($sql);
                                $st->execute();
                                ?>

                                <?php
                                $pages = 1;
                                while ($row = $st->fetch()) {
                                    ?> 
                                    <tr>
                                        <td> <?php echo $row['day']; ?></td>
                                        <td><?php echo $row['teaching_hour_id']; ?></td>
                                        <td><?php echo $row['start_time']; ?></td>
                                        <td><?php echo $row['end_time']; ?></td>
                                        <td><?php echo $row['roomname']; ?></td>
                                        <td><?php echo $row['teachername']; ?></td>
                                        <td><?php echo $row['tlastname']; ?></td>

                                        <td><?php echo $row['name']; ?></td>
                                    </tr>
                                    <?php
                                    $pages += 1;
                                }
                                ?>
                            </table></td>


                    </tr>
                    <tr><td>
                            YEAR 3

                            <table class="dataList_table timetable_view">
                                <tr><td>DAY</td>
                                    <td>HOUR</td>
                                    <td>START HOUR</td>
                                    <td>END HOUR</td>
                                    <td>ROOM</td>
                                    <td>LECTURER First name</td>
                                    <td>LECTURER Last name</td>

                                    <td>COURSE</td>
                                </tr>
                                <?php
                                $database = new dbconnection();
                                $db = $database->openConnection();
                                $sql = " SELECT time_table.time_table_id,teaching_day.day, teaching_hour.teaching_hour_id, teaching_hour.start_time,teaching_hour.end_time,room.name as 'roomname',course.name, years.name as 'yearname',lecturer.lecturer_id,profile.name as 'teachername', profile.last_name as 'tlastname' from time_table join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day join room on room.room_id-time_table.room join academic_year on academic_year.academic_year_id=time_table.academic_year join lecturer_course on lecturer_course.lecturer_course_id=time_table.course join lecturer on lecturer_course.lecturer=lecturer.lecturer_id JOIN account on account.account_id=time_table.User join profile on profile.profile_id=account.profile join course on lecturer_course.Course=course.course_id join course_year on course_year.course=course.course_id join years on years.years_id=course_year.year WHERE years.name='Year 3' GROUP BY time_table.time_table_id";
                                $st = $db->prepare($sql);
                                $st->execute();
                                ?>

                                <?php
                                $pages = 1;
                                while ($row = $st->fetch()) {
                                    ?> 
                                    <tr>
                                        <td> <?php echo $row['day']; ?></td>
                                        <td><?php echo $row['teaching_hour_id']; ?></td>
                                        <td><?php echo $row['start_time']; ?></td>
                                        <td><?php echo $row['end_time']; ?></td>
                                        <td><?php echo $row['roomname']; ?></td>
                                        <td><?php echo $row['teachername']; ?></td>
                                        <td><?php echo $row['tlastname']; ?></td>

                                        <td><?php echo $row['name']; ?></td>
                                    </tr>
                                    <?php
                                    $pages += 1;
                                }
                                ?>
                            </table></td>


                    </tr>
                </table>
                <?php
            }
        }

        function list_lec_timetable($lec_id) {
            ?>
            <table class="dataList_table timetable_view">

                <tr><td>
                        YEAR 1
                        <table class="dataList_table timetable_view">
                            <tr><td>DAY</td>
                                <td>HOUR</td>
                                <td>START HOUR</td>
                                <td>END HOUR</td>
                                <td>ROOM</td>
                                <td>LECTURER First name</td>
                                <td>LECTURER Last name</td>

                                <td>COURSE</td>
                            </tr>
                            <?php
                            $database = new dbconnection();
                            $db = $database->openConnection();
                            if (true) {//lecturer
                            }
                            $sql = " SELECT time_table.time_table_id,teaching_day.day, teaching_hour.teaching_hour_id, teaching_hour.start_time,teaching_hour.end_time,room.name as 'roomname',course.name, years.name as 'yearname',lecturer.lecturer_id,profile.name as 'teachername', profile.last_name as 'tlastname' from time_table join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day join room on room.room_id-time_table.room join academic_year on academic_year.academic_year_id=time_table.academic_year join lecturer_course on lecturer_course.lecturer_course_id=time_table.course join lecturer on lecturer_course.lecturer=lecturer.lecturer_id JOIN account on account.account_id=time_table.User join profile on profile.profile_id=account.profile join course on lecturer_course.Course=course.course_id join course_year on course_year.course=course.course_id join years on years.years_id=course_year.year WHERE years.name='Year 1' and lecturer.lecturer_id='$lec_id'
                                GROUP BY time_table.time_table_id ";

                            $st = $db->prepare($sql);
                            $st->execute();
                            ?>

                            <?php
                            $pages = 1;
                            while ($row = $st->fetch()) {
                                ?> 
                                <tr>
                                    <td> <?php echo $row['day']; ?></td>
                                    <td><?php echo $row['teaching_hour_id']; ?></td>
                                    <td><?php echo $row['start_time']; ?></td>
                                    <td><?php echo $row['end_time']; ?></td>
                                    <td><?php echo $row['roomname']; ?></td>
                                    <td><?php echo $row['teachername']; ?></td>
                                    <td><?php echo $row['tlastname']; ?></td>

                                    <td><?php echo $row['name']; ?></td>
                                </tr>
                                <?php
                                $pages += 1;
                            }
                            ?>
                        </table></td>
                </tr>
                <tr><td>
                        YEAR 2

                        <table class="dataList_table timetable_view">
                            <tr><td>DAY</td>
                                <td>HOUR</td>
                                <td>START HOUR</td>
                                <td>END HOUR</td>
                                <td>ROOM</td>
                                <td>LECTURER First name</td>
                                <td>LECTURER Last name</td>

                                <td>COURSE</td>
                            </tr>
                            <?php
                            $database = new dbconnection();
                            $db = $database->openConnection();
                            $sql = " SELECT time_table.time_table_id,teaching_day.day, teaching_hour.teaching_hour_id, teaching_hour.start_time,teaching_hour.end_time,room.name as 'roomname',course.name, years.name as 'yearname',lecturer.lecturer_id,profile.name as 'teachername', profile.last_name as 'tlastname' from time_table join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day join room on room.room_id-time_table.room join academic_year on academic_year.academic_year_id=time_table.academic_year join lecturer_course on lecturer_course.lecturer_course_id=time_table.course join lecturer on lecturer_course.lecturer=lecturer.lecturer_id JOIN account on account.account_id=time_table.User join profile on profile.profile_id=account.profile join course on lecturer_course.Course=course.course_id join course_year on course_year.course=course.course_id join years on years.years_id=course_year.year WHERE years.name='Year 2' and lecturer.lecturer_id='$lec_id'
GROUP BY time_table.time_table_id";

                            $st = $db->prepare($sql);
                            $st->execute();
                            ?>

                            <?php
                            $pages = 1;
                            while ($row = $st->fetch()) {
                                ?> 
                                <tr>
                                    <td> <?php echo $row['day']; ?></td>
                                    <td><?php echo $row['teaching_hour_id']; ?></td>
                                    <td><?php echo $row['start_time']; ?></td>
                                    <td><?php echo $row['end_time']; ?></td>
                                    <td><?php echo $row['roomname']; ?></td>
                                    <td><?php echo $row['teachername']; ?></td>
                                    <td><?php echo $row['tlastname']; ?></td>

                                    <td><?php echo $row['name']; ?></td>
                                </tr>
                                <?php
                                $pages += 1;
                            }
                            ?>
                        </table></td>


                </tr>
                <tr><td>
                        YEAR 3

                        <table class="dataList_table timetable_view">
                            <tr><td>DAY</td>
                                <td>HOUR</td>
                                <td>START HOUR</td>
                                <td>END HOUR</td>
                                <td>ROOM</td>
                                <td>LECTURER First name</td>
                                <td>LECTURER Last name</td>

                                <td>COURSE</td>
                            </tr>
                            <?php
                            $database = new dbconnection();
                            $db = $database->openConnection();
                            $sql = " SELECT time_table.time_table_id,teaching_day.day, teaching_hour.teaching_hour_id, teaching_hour.start_time,teaching_hour.end_time,room.name as 'roomname',course.name, years.name as 'yearname',lecturer.lecturer_id,profile.name as 'teachername', profile.last_name as 'tlastname' from time_table join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day join room on room.room_id-time_table.room join academic_year on academic_year.academic_year_id=time_table.academic_year join lecturer_course on lecturer_course.lecturer_course_id=time_table.course join lecturer on lecturer_course.lecturer=lecturer.lecturer_id JOIN account on account.account_id=time_table.User join profile on profile.profile_id=account.profile join course on lecturer_course.Course=course.course_id join course_year on course_year.course=course.course_id join years on years.years_id=course_year.year WHERE years.name='Year 3' and lecturer.lecturer_id='$lec_id'
GROUP BY time_table.time_table_id";
                            $st = $db->prepare($sql);
                            $st->execute();
                            ?>

                            <?php
                            $pages = 1;
                            while ($row = $st->fetch()) {
                                ?> 
                                <tr>
                                    <td> <?php echo $row['day']; ?></td>
                                    <td><?php echo $row['teaching_hour_id']; ?></td>
                                    <td><?php echo $row['start_time']; ?></td>
                                    <td><?php echo $row['end_time']; ?></td>
                                    <td><?php echo $row['roomname']; ?></td>
                                    <td><?php echo $row['teachername']; ?></td>
                                    <td><?php echo $row['tlastname']; ?></td>

                                    <td><?php echo $row['name']; ?></td>
                                </tr>
                                <?php
                                $pages += 1;
                            }
                            ?>
                        </table></td>


                </tr>
            </table>
            <?php
        }

        function list_time_table() {
            $database = new dbconnection();
            $db = $database->openConnection();
            //get the years
            $sql_year = "select years.years_id ,years.name as year from years";
            $stmt_year = $db->prepare($sql_year);
            $stmt_year->execute();
            ?> 
            <?php
            while ($row_year = $stmt_year->fetch()) {
                ?><div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border xx_titles">
                        <?php echo $row_year['year']; ?>
                    </div>
                    <?php
                    $this->list_timetable_by_year($row_year['years_id']);
                    ?></div>
            <?php }
            ?> <?php
            //Get the time table by years
        }

        function list_time_table_student($account) {
            $database = new dbconnection();
            $db = $database->openConnection();
            //get the years
            $sql_year = "select years.years_id,years.name as year from years
                            join streams on streams.year=years.years_id
                            join student_reg on student_reg.stream=streams.streams_id
                            join student on student_reg.student=student.student_id
                            join account on account.account_id=student.account
                            where account.account_id=:account 
                            ";
            $stmt_year = $db->prepare($sql_year);
            $stmt_year->execute(array(":account" => $account));
            ?> 
            <?php
            while ($row_year = $stmt_year->fetch()) {
                ?><div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border xx_titles">
                        <?php echo $row_year['year']; ?>
                    </div>
                    <?php
                    $this->list_timetable_by_year($row_year['years_id']);
                    ?></div>
            <?php }
            ?> <?php
            //Get the time table by years
        }

        function list_timetable_by_year($year) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql_time_table = " SELECT years.years_id,academic_year.start_year ,academic_year.end_year, time_table.time_table_id,teaching_day.day as teaching_day,time_table.entry_date, teaching_hour.teaching_hour_id as teaching_hour, teaching_hour.start_time,teaching_hour.end_time,room.name as 'room',course.name as course, years.name as 'yearname',lecturer.lecturer_id,profile.name as prof_name, profile.last_name  from time_table 
                                    join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour
                                    join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day
                                    join room on room.room_id=time_table.room 
                                    join academic_year on academic_year.academic_year_id=time_table.academic_year 
                                    join lecturer_course on lecturer_course.lecturer_course_id=time_table.course 
                                    JOIN account on account.account_id=time_table.User 
                                    join profile on profile.profile_id=account.profile 
                                    join course on lecturer_course.Course=course.course_id 
                                    join lecturer on lecturer.lecturer_id= lecturer_course.lecturer
                                    join course_year on course_year.course=course.course_id
                                    join years on years.years_id=course_year.year                                                
                                    WHERE years.years_id=:year 
                                    group by time_table.time_table_id
                                    order by  teaching_day.teaching_day_id, teaching_hour.teaching_hour_id asc
                                    ";
            $stmt_time_table = $db->prepare($sql_time_table);
            $stmt_time_table->execute(array(":year" => $year));
            ?>
            <table class="dataList_table">
                <tr>
                    <td colspan="7"></td>
                </tr>
                <thead><tr>
                        <td class="off"> S/N </td>
                        <td> Hour </td>
                        <td> Day </td>
                        <td> Room </td>
                        <td> Ac.Year </td>
                        <td> Course </td>
                        <td> Lecturer </td>
                        <td> Date </td> 
                        <td> Delete </td> 
                        <td> Update </td> 
                    </tr>
                </thead>

                <?php
                $pages = 1;
                while ($row = $stmt_time_table->fetch()) {
                    ?><tr> 
                        <td class="off">
                            <?php echo $row['time_table_id']; ?>
                        </td>
                        <td class="teaching_hour_id_cols time_table " title="time_table" >
                            <?php
                            echo $this->_e($row['start_time']) . ' - ';
                            echo $row['end_time'];
                            ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['teaching_day']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['room']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['start_year']) . ' - ' . $row['end_year']; ?>
                        </td>
                        <td>       <?php echo $this->_e($row['course']); ?></td>
                        <td>       <?php
                            echo $this->_e($row['prof_name']) . ' ';
                            echo $row['last_name'];
                            ?></td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td><a href="#" class="time_table_delete_link" data-table="time_table" data-id_delete="<?php echo $row['time_table_id']; ?>" style="color: #0040ff;">Delete</a></td>
                        <td><a href="#" class="time_table_update_link" data-table="time_table" value="<?php echo $row['time_table_id']; ?>" style="color: #0040ff;">Update</a></td>

                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_time_table_teaching_hour($id) {

            $db = new dbconnection();
            $sql = "select   time_table.teaching_hour from time_table where time_table_id=:time_table_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':time_table_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['teaching_hour'];
            echo $field;
        }

        function get_chosen_time_table_teaching_day($id) {

            $db = new dbconnection();
            $sql = "select   time_table.teaching_day from time_table where time_table_id=:time_table_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':time_table_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['teaching_day'];
            echo $field;
        }

        function get_chosen_time_table_room($id) {

            $db = new dbconnection();
            $sql = "select   time_table.room from time_table where time_table_id=:time_table_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':time_table_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['room'];
            echo $field;
        }

        function get_chosen_time_table_academic_year($id) {

            $db = new dbconnection();
            $sql = "select   time_table.academic_year from time_table where time_table_id=:time_table_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':time_table_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['academic_year'];
            echo $field;
        }

        function get_chosen_time_table_course($id) {

            $db = new dbconnection();
            $sql = "select   time_table.course from time_table where time_table_id=:time_table_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':time_table_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['course'];
            echo $field;
        }

        function get_chosen_time_table_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   time_table.entry_date from time_table where time_table_id=:time_table_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':time_table_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_time_table_User($id) {

            $db = new dbconnection();
            $sql = "select   time_table.User from time_table where time_table_id=:time_table_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':time_table_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_time_table() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  time_table_id   from time_table";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_time_table() {
            $con = new dbconnection();
            $sql = "select time_table.time_table_id from time_table
                    order by time_table.time_table_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['time_table_id'];
            return $first_rec;
        }

        function get_last_time_table() {
            $con = new dbconnection();
            $sql = "select time_table.time_table_id from time_table
                    order by time_table.time_table_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['time_table_id'];
            return $first_rec;
        }

        function list_student($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "SELECT student.reg_number,student.student_id, profile.name, profile.last_name, profile.gender,account.account_category,account.username from profile "
                    . "JOIN account on profile.profile_id = account.profile "
                    . "JOIN student ON student.account = account.account_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> Registration Number </td>
                        <td> First Name </td>
                        <td> Last Name </td>
                        <td> Gender </td>
                        <td> User Name </td>
                        <td> Delete </td>
                        <td> Update </td>
                    </tr></thead>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 
                        <td>
                            <?php echo $row['reg_number']; ?>
                        </td>
                        <td class="account_id_cols student " title="student" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['gender']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>
                        <td>
                            <a href="#"  class="student_delete_link" data-table="student" data-id_delete="<?php echo $row['student_id']; ?>" style="color: #0033ff">Delete</a>
                        </td>
                        <td>
                            <a href="#"  class="student_update_link" value="<?php echo $row['student_id']; ?>" style="color: #0033ff">Update</a>
                        </td>
                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

        function list_student_studentdashboard($account) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "SELECT student.reg_number, profile.name, profile.last_name, profile.gender,account.account_category,account.username from profile "
                    . "JOIN account on profile.profile_id = account.profile "
                    . "JOIN student ON student.account = account.account_id "
                    . " where account.account_id=:account";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":account" => $account));
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> Registration Number </td>
                        <td> First Name </td>
                        <td> Last Name </td>
                        <td> Gender </td>
                        <td> User Name </td>
                    </tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['reg_number']; ?>
                        </td>
                        <td class="account_id_cols student " title="student" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['gender']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>

                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_student_account($id) {

            $db = new dbconnection();
            $sql = "select   student.account from student where student_id=:student_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':student_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_student_reg_number($id) {

            $db = new dbconnection();
            $sql = "select   student.reg_number from student where student_id=:student_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':student_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['reg_number'];
            echo $field;
        }

        function All_student() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  student_id   from student";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_student() {
            $con = new dbconnection();
            $sql = "select student.student_id from student
                    order by student.student_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['student_id'];
            return $first_rec;
        }

        function get_last_student() {
            $con = new dbconnection();
            $sql = "select student.student_id from student
                    order by student.student_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['student_id'];
            return $first_rec;
        }

        function get_account_category_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account_category.account_category_id,   account_category.name from account_category";
            ?>
            <select class="textbox cbo_account_category"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_profile_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select profile.profile_id,   profile.name from profile";
            ?>
            <select class="textbox cbo_profile"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_image_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select image.image_id,   image.name from image";
            ?>
            <select class="textbox cbo_image"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_year_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select years.years_id,   years.name from years "
                    . " ";
            ?>
            <select class="textbox cbo_year"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['years_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_ac_year_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select academic_year.academic_year_id,   academic_year.start_year,academic_year.end_year from academic_year";
            ?>
            <select class="textbox cbo_ac_year"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['academic_year_id'] . ">" . $row['start_year'] . " - " . $row['end_year'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_stream_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select streams.streams_id,   streams.name, years.name as year from streams "
                    . " join years on years.years_id=streams.year ";
            ?>
            <select class="textbox cbo_stream"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['streams_id'] . ">" . $row['year'] . " / " . $row['name'] . "</option>";
                }
                ?>
            </select>
            <?php
        }

        function get_student_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select student.student_id, student.reg_number,  profile.name,  profile.last_name from student "
                    . " join account on account.account_id=student.account
                        join profile on profile.profile_id=account.profile";
            ?>
            <select class="textbox cbo_student"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['student_id'] . ">" . $row['name'] . " - " . $row['last_name'] . " / " . $row['reg_number'] . "</option>";
                }
                ?>
            </select>
            <?php
        }

        function get_lecturer_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select lecturer.lecturer_id,   lecturer.account,profile.name,  profile.last_name from lecturer "
                    . "  join account on account.account_id=lecturer.account
                        join profile on profile.profile_id=account.profile";
            ?>
            <select class="textbox cbo_lecturer"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['lecturer_id'] . ">" . $row['name'] . " " . $row['last_name'] . "   </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_Course_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select Course.Course_id, Course.name from Course";
            ?>
            <select class="textbox cbo_Course"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['Course_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_lectrer_Course_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = " select lecturer_course.lecturer_course_id, profile.name,  profile.last_name, course.name as course
                from lecturer_course 
                   join lecturer on lecturer.lecturer_id=lecturer_course.lecturer
                    join account on account.account_id=lecturer.account
                    join profile on profile.profile_id=account.profile 
                     join course on course.course_id=lecturer_course.Course";
            ?>
            <select class="textbox cbo_Course"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['lecturer_course_id'] . ">" . $row['name'] . " " . $row['last_name'] . " / " . $row['course'] . "</option>";
                }
                ?>
            </select>
            <?php
        }

        function get_hod_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = " SELECT account.account_id, profile.name, profile.last_name FROM `account`  
                join profile on profile.profile_id=account.profile
                JOIN account_category ON account_category.account_category_id = account.account_category
                WHERE account_category.name = 'hod'";
            ?>
            <select class="textbox cbo_hod"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " " . $row['last_name'] . "</option>";
                }
                ?>
            </select>
            <?php
        }

        function get_time_table_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select time_table.time_table_id,   time_table.name from time_table";
            ?>
            <select class="textbox cbo_time_table"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['time_table_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_teaching_hour_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select teaching_hour.teaching_hour_id,   teaching_hour.start_time, teaching_hour.end_time from teaching_hour";
            ?>
            <select class="textbox cbo_teaching_hour"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['teaching_hour_id'] . ">" . $row['start_time'] . "    -    " . $row['end_time'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_teaching_day_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select teaching_day.teaching_day_id,   teaching_day.day from teaching_day";
            ?>
            <select class="textbox cbo_teaching_day"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['teaching_day_id'] . ">" . $row['day'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_room_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select room.room_id,   room.name from room ";
            ?>
            <select class="textbox cbo_room"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['room_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_academic_year_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select academic_year.academic_year_id,   academic_year.start_year,academic_year.end_year  from academic_year";
            ?>
            <select class="textbox cbo_academic_year"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['academic_year_id'] . ">" . $row['start_year'] . " - " . $row['end_year'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_account_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account.account_id,   account.name from account";
            ?>
            <select class="textbox cbo_account"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_timetable_exits($day, $hour, $course, $room, $ac_year) {
            $con = new dbconnection();
            $sql = "select time_table_id from time_table  
                    where time_table.teaching_day =:day 
                    and time_table.teaching_hour=:hour
                    and time_table.course=:course
                    and time_table.room=:room
                    and time_table.academic_year=:acyear ";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":day" => $day, ":hour" => $hour, ":course" => $course, ":room" => $room, ":acyear" => $ac_year));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['time_table_id'];
            return $first_rec;
        }

        function get_lecturer_course_exits($lecturer, $course) {
            $con = new dbconnection();
            $sql = "select lecturer_course_id from lecturer_course 
                    where lecturer_course.lecturer=:lecturer and lecturer_course.Course=:course ";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":lecturer" => $lecturer, ":course" => $course));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['lecturer_course_id'];
            return $first_rec;
        }

        function get_user_username_by_user($username) {
            $con = new dbconnection();
            $sql = "select    username  from account   where  account.username =:username";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":username" => $username));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['username'];
            return $userid;
        }

        function get_student_already_registered($year, $stream, $student) {
            $con = new dbconnection();
            $sql = "select student_reg_id from student_reg 
                where student_reg.ac_year=:year
                and student_reg.stream=:stream
                    and student_reg.student=:student";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":year" => $year, ":stream" => $stream, ":student" => $student));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['student_reg_id'];
            return $userid;
        }

        function list_lecturer_years($user) {
            $database = new dbconnection();
            $db = $database->openConnection();
            //get the years
            $sql_year = "select years.years_id,years.name as year, course.name as course from course_year  
                            join years on years.years_id=course_year.year
                            join course on course_year.course=course.course_id 
                            join lecturer_course on course.course_id=lecturer_course.course
                            join lecturer on lecturer.lecturer_id=lecturer_course.lecturer
                            join account on account.account_id=lecturer.account
                             where account.account_id=:account
                             ";
            $stmt_year = $db->prepare($sql_year);
            $stmt_year->execute(array(":account" => $user));
            while ($row_year = $stmt_year->fetch()) {
                ?><div class="parts no_paddin_shade_no_Border full_center_two_h heit_free">
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border xx_titles">
                        <?php echo $row_year['year']; ?>
                    </div>
                    <?php
                    $this->list_timetable_lecturer_by_year($row_year['years_id']);
                    ?></div>
                <?php
            }
        }

        function list_timetable_lecturer_by_year($year) {
            $database = new dbconnection();
            $con = $database->openConnection();
            $sql = "SELECT years.years_id,academic_year.start_year as academic_year, time_table.time_table_id,teaching_day.day as teaching_day,time_table.entry_date, teaching_hour.teaching_hour_id as teaching_hour, teaching_hour.start_time,teaching_hour.end_time,room.name as 'room',course.name as course, years.name as 'yearname',lecturer.lecturer_id,profile.name as teachername, profile.last_name as tlastname from time_table 
                                    join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour
                                    join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day
                                    join room on room.room_id-time_table.room 
                                    join academic_year on academic_year.academic_year_id=time_table.academic_year 
                                    join lecturer_course on lecturer_course.lecturer_course_id=time_table.course 
                                    join lecturer on lecturer.lecturer_id= lecturer_course.lecturer
				    join course on lecturer_course.Course=course.course_id 
                                    join account on account.account_id=lecturer.account
                                    join profile on profile.profile_id=account.profile 
                                    join course_year on course_year.course=course.course_id
                                    join years on years.years_id=course_year.year
                                    where years.years_id=:year
                                     group by time_table.time_table_id 
                                    ";
            $stmt = $con->prepare($sql);
            $stmt->execute(array(":year" => $year));
            while ($row = $stmt->fetch()) {
                ?><table class="dataList_table full_center_two_h heit_free">
                    <thead><tr>
                            <td> S/N </td>
                            <td> Hour </td>
                            <td> Day </td>
                            <td> Room </td>
                            <td> Ac.Year </td>
                            <td> Course </td>

                        </tr>
                    </thead>  
                    <tr> 
                        <td>
                            <?php echo $row['time_table_id']; ?>
                        </td>
                        <td class="teaching_hour_id_cols time_table " title="time_table" >
                            <?php
                            echo $this->_e($row['start_time']) . ' - ';
                            echo $row['end_time'];
                            ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['teaching_day']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['room']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['academic_year']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['course']); ?>
                        </td>


                    </tr>
                    <?php
                }
            }

            function get_if_year_course($course, $year) {
                $con = new dbconnection();
                $sql = "select course_year.course from course_year where course_year.course=:course and course_year.year=:year";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":course" => $course, ":year" => $year));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $userid = $row['course'];
                return $userid;
            }

            function get_credits_left_by_course_lec($crs_lec) {
                $con = new dbconnection();
                $db = $con->openconnection();
                $sql = "SELECT course.course_id, time_table.time_table_id, course.no_credits  from time_table 
                                    join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour
                                    join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day
                                    join room on room.room_id=time_table.room 
                                    join academic_year on academic_year.academic_year_id=time_table.academic_year 
                                    join lecturer_course on lecturer_course.lecturer_course_id=time_table.course 
                                    join course on lecturer_course.Course=course.course_id 
                       where lecturer_course.lecturer_course_id=:course_lec
                        group by course.course_id";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":course_lec" => $crs_lec));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row['no_credits'];
            }

            function get_assigned_courses_by_year_ac($course, $ac_year) {//this calculates the hours give in the timetable and the expected credits. This means that if in year 1 study Java and Java has 20 credits which are equal to 8 hours the system wont allow to exceed 6 hours
                $con = new dbconnection();
                $db = $con->openconnection();
                $sql = "SELECT count(course.course_id) as tot, time_table.time_table_id, course.no_credits  from time_table 
                                    join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour
                                    join teaching_day on teaching_day.teaching_day_id=time_table.teaching_day
                                    join room on room.room_id=time_table.room 
                                    join academic_year on academic_year.academic_year_id=time_table.academic_year 
                                    join lecturer_course on lecturer_course.lecturer_course_id=time_table.course 
                                    join course on lecturer_course.Course=course.course_id 
                                     join course_year on course_year.course=course.course_id
                                    join years on years.years_id=course_year.year   
                                    where lecturer_course.lecturer_course_id=:course and academic_year.academic_year_id=:academic_year  
				    group by academic_year.academic_year_id  
                                    ";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":course" => $course, ":academic_year" => $ac_year));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row['tot'];
            }

            function get_course_year_by_year($course) {
                $con = new dbconnection();
                $db = $con->openconnection();
                $sql = "SELECT course_year.year FROM automatic_timetable.course_year
                        join course on course.course_id=course_year.course
                        join lecturer_course on lecturer_course.course=course.course_id
                        where lecturer_course.lecturer_course_id=:course";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":course" => $course));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row['year'];
            }

            // <editor-fold defaultstate="collapsed" desc="--------This is the updating timetable -----------">


            function get_teaching_hour_by_timetable($time_table) {
                $con = new dbconnection();
                $db = $con->openconnection();
                $sql = "select teaching_hour from time_table where time_table.time_table_id=:timetable";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":timetable" => $time_table));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row['teaching_hour'];
            }

            function get_teaching_day_by_timetable($time_table) {
                $con = new dbconnection();
                $db = $con->openconnection();
                $sql = "select teaching_day from time_table where time_table.time_table_id=:timetable";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":timetable" => $time_table));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row['teaching_day'];
            }

            function get_room_by_timetable($time_table) {
                $con = new dbconnection();
                $db = $con->openconnection();
                $sql = "select room from time_table where time_table.time_table_id=:timetable";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":timetable" => $time_table));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row['room'];
            }

            function get_ac_year_by_timetable($time_table) {
                $con = new dbconnection();
                $db = $con->openconnection();
                $sql = "select academic_year from time_table where time_table.time_table_id=:timetable";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":timetable" => $time_table));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row['academic_year'];
            }

            function get_course_timetable($time_table) {
                $con = new dbconnection();
                $db = $con->openconnection();
                $sql = "select course from time_table where time_table.time_table_id=:timetable";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":timetable" => $time_table));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row['course'];
            }

            // </editor-fold>
            function _e($string) {
                echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
            }

        }
        