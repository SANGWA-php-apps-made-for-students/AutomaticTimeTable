<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_course_taken'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'course_taken') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $course_taken_id = $_SESSION['id_upd'];

                $course = trim($_POST['txt_course_id']);
                $lecturer = $_POST['txt_lecturer_id'];

                $course = $_POST['txt_course_id'];

                $entry_date = date("y-m-d");

                $User = $_SESSION['userid'];



                $upd_obj->update_course_taken($course, $lecturer, $course, $entry_date, $User, $course_taken_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $course = trim($_POST['txt_course_id']);
            $lecturer = trim($_POST['txt_lecturer_id']);
            $course = trim($_POST['txt_course_id']);
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];

            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_course_taken($course, $lecturer, $course, $entry_date, $User);
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            course_taken</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_course_taken.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_course_id"   name="txt_course_id"/><input type="hidden" id="txt_lecturer_id"   name="txt_lecturer_id"/><input type="hidden" id="txt_course_id"   name="txt_course_id"/>
            <?php
                include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                course_taken saved successfully!</div>


            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  course_taken Registration </div>
                <table class="new_data_table">


                    <tr><td class="new_data_tb_frst_cols">Course </td><td> <?php get_course_combo(); ?>  </td></tr> <tr><td class="new_data_tb_frst_cols">Lecturer </td><td> <?php get_lecturer_combo(); ?>  </td></tr> <tr><td class="new_data_tb_frst_cols">Course </td><td> <?php get_course_combo(); ?>  </td></tr>

                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_course_taken" value="Save"/>  </td></tr>
                </table>
            </div>


            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">course_taken List</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_course_taken();
                    $obj->list_course_taken($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function chosen_course_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'course_taken') {
                $id = $_SESSION['id_upd'];
                $course = new multi_values();
                return $course->get_chosen_course_taken_course($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_lecturer_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'course_taken') {
                $id = $_SESSION['id_upd'];
                $lecturer = new multi_values();
                return $lecturer->get_chosen_course_taken_lecturer($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'course_taken') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_course_taken_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'course_taken') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_course_taken_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    