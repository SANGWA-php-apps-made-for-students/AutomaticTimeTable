<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_student'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $student_id = $_SESSION['id_upd'];
                $account = trim($_POST['txt_account_id']);
                $reg_number = $_POST['txt_reg_number'];
                $upd_obj->update_student($account, $reg_number, $student_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $account = trim($_POST['txt_account_id']);
//            $reg_number = $_POST['txt_reg_number'];
            require_once '../web_db/new_values.php';
            require_once '../web_db/multi_values.php';
            $m = new multi_values();
            $obj = new new_values();
            //profile
            $dob = date("y-m-d h:m:s"); //$_POST['txt_dob'];
            $name = $_POST['txt_name'];
            $last_name = $_POST['txt_last_name'];
            $gender = $_POST['txt_gender'];
            $telephone_number = ''; //$_POST['txt_telephone_number'];
            $email = ''; //$_POST['txt_email'];
            $residence = ''; //$_POST['txt_residence'];
            $image = 0;
            $username = $_POST['txt_username'];
            $password = $_POST['txt_password'];

            $mul = new multi_values();
            if (!empty($mul->get_user_username_by_user($username))) {
                ?><script>alert('The user with the same username already exists, please user another username');</script><?php
            } else {
                $obj->new_profile(date("y-m-d"), $name, $last_name, $gender, $telephone_number, $email, $residence, $image);
                $last_profile = $m->get_last_profile();


                //account
                $account_category = 4; // this is hod;
                $date_created = ''; //$_POST['txt_date_created'];
                $profile = 0; // trim($_POST['txt_profile_id']);

                $is_online = 'yes'; //$_POST['txt_is_online'];
                $obj->new_account($account_category, date("y-m-d"), $last_profile, $username, $password, $is_online);

                $last_acc = $m->get_last_account();
                //Lecturer
                $edu_level = $_POST['txt_edu_level'];
                
                
            }
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            Head of department</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_hod.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <?php
                include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                student saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  Hod Registration </div>
                <table class="new_data_table">
                    <tr><td><label for="txt_name">Name </label></td><td> <input type="text"     name="txt_name" required id="txt_name" class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_edu_level">Education Level </label></td><td> <input type="text"     name="txt_edu_level" required id="txt_edu_level" class="textbox" value="<?php echo trim(chosen_edu_level_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_last_name">Last name </label></td><td> <input type="text"     name="txt_last_name" required id="txt_last_name" class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                    <tr><td>Gender</td><td>
                            <label for="txt_male"><input type="radio" value="male" name="txt_gender" id="txt_male"/>   Male </label> 
                            <label for="txt_female">  <input type="radio" value="female" name="txt_gender" id="txt_female"/>Female </label>  

                    <tr><td><label for="txt_username">Username </label></td><td> <input type="text"     name="txt_username" required id="txt_username" class="textbox" value="<?php echo trim(chosen_username_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_password">Password</label></td><td> <input type="password"     name="txt_password" required id="txt_password" class="textbox" value="<?php echo trim(chosen_password_upd()); ?>"   />  </td></tr>

                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_student" value="Save"/>  </td></tr>
                </table>
            </div>


            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">Heads of departments List</div>
                <?php
                    $obj = new multi_values();

                    $obj->list_hod();
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_account_combo() {
        $obj = new multi_values();
        $obj->get_account_in_combo();
    }

    function chosen_account_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student') {
                $id = $_SESSION['id_upd'];
                $account = new multi_values();
                return $account->get_chosen_student_account($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_reg_number_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student') {
                $id = $_SESSION['id_upd'];
                $reg_number = new multi_values();
                return $reg_number->get_chosen_student_reg_number($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    // <editor-fold defaultstate="collapsed" desc="----profile ------">

    function get_image_combo() {
        $obj = new multi_values();
        $obj->get_profile_in_combo();
    }

    function chosen_dob_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'profile') {
                $id = $_SESSION['id_upd'];
                $dob = new multi_values();
                return $dob->get_chosen_profile_dob($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_name_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'profile') {
                $id = $_SESSION['id_upd'];
                $name = new multi_values();
                return $name->get_chosen_profile_name($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_last_name_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'profile') {
                $id = $_SESSION['id_upd'];
                $last_name = new multi_values();
                return $last_name->get_chosen_profile_last_name($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_gender_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'profile') {
                $id = $_SESSION['id_upd'];
                $gender = new multi_values();
                return $gender->get_chosen_profile_gender($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_telephone_number_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'profile') {
                $id = $_SESSION['id_upd'];
                $telephone_number = new multi_values();
                return $telephone_number->get_chosen_profile_telephone_number($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_email_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'profile') {
                $id = $_SESSION['id_upd'];
                $email = new multi_values();
                return $email->get_chosen_profile_email($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_residence_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'profile') {
                $id = $_SESSION['id_upd'];
                $residence = new multi_values();
                return $residence->get_chosen_profile_residence($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_image_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'profile') {
                $id = $_SESSION['id_upd'];
                $image = new multi_values();
                return $image->get_chosen_profile_image($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="-----account-------">

    function get_account_category_combo() {
        $obj = new multi_values();
        $obj->get_account_category_in_combo();
    }

    function get_profile_combo() {
        $obj = new multi_values();
        $obj->get_profile_in_combo();
    }

    function get_acc_type_combo() {
        $obj = new multi_values();
        $obj->get_acc_type_in_combo();
    }

    function chosen_account_category_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'account') {
                $id = $_SESSION['id_upd'];
                $account_category = new multi_values();
                return $account_category->get_chosen_account_account_category($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_date_created_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'account') {
                $id = $_SESSION['id_upd'];
                $date_created = new multi_values();
                return $date_created->get_chosen_account_date_created($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_profile_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'account') {
                $id = $_SESSION['id_upd'];
                $profile = new multi_values();
                return $profile->get_chosen_account_profile($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_username_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'account') {
                $id = $_SESSION['id_upd'];
                $username = new multi_values();
                return $username->get_chosen_account_username($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_password_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'account') {
                $id = $_SESSION['id_upd'];
                $password = new multi_values();
                return $password->get_chosen_account_password($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_is_online_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'account') {
                $id = $_SESSION['id_upd'];
                $is_online = new multi_values();
                return $is_online->get_chosen_account_is_online($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_edu_level_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'lecturer') {
                $id = $_SESSION['id_upd'];
                $edu_level = new multi_values();
                return $edu_level->get_chosen_lecturer_edu_level($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

// </editor-fold>
