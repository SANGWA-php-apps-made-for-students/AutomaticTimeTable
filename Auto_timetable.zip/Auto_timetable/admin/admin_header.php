<div class="parts  eighty_centered ">         
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        Automatic Timetable  
    </div>
</div>   
<div class="parts menu eighty_centered">
    <a href="admin_dashboard.php">Home</a>
    <?php
        if ($_SESSION['cat'] == 'hod') {
            ?>
            <a href="new_department.php">department</a>

            <?php
        }
    ?>
    <div class="parts allow_drop margin_free no_paddin_shade_no_Border">
        Users
        <div class="parts hovable_item">
            <?php
                if ($_SESSION['cat'] == 'lecturer') {
                    ?><a href="new_lecturer.php">Lecturer</a>
                    <?php
                } elseif ($_SESSION['cat'] == 'student') {
                    ?>
                    <a href="new_student.php">Student</a>
                    <?php
                } elseif ($_SESSION['cat'] == 'hod') {
                    ?>
                    <a href="new_student.php">Student</a>
                    <a href="new_lecturer.php">Lecturer</a>
                <?php } else {
                    ?>
                    <a href="new_lecturer.php">Lecturer</a>
                    <a href="new_student.php">Student</a>

                    <a href="new_lecturer.php">Lecturer</a>
                    <a href="new_hod.php">Head of department</a>

                    <?php
                }
            ?>

        </div>
    </div>
    <div class="parts allow_drop margin_free no_paddin_shade_no_Border">
        <?php
            if ($_SESSION['cat'] != 'student') {
                ?>
                Academics
                <?php
            }
        ?>
        <div class="parts hovable_item">
            <?php
                if ($_SESSION['cat'] == 'lecturer') {
                    ?>   <a href="new_lecturer_course.php">lecturer course</a>    <?php
                } elseif ($_SESSION['cat'] == 'student') {
                    
                } elseif ($_SESSION['cat'] == 'hod') {
                    ?>
                    <a href="new_streams.php">streams</a>
                    <a href="new_student_reg.php">student Registration</a>
                    <a href="new_academic_year.php">academic year</a>
                    <a href="new_course.php">course</a>
                    <a href="new_lecturer.php">lecturer</a>
                    <a href="new_lecturer_course.php">lecturer course</a>
                    <a href="new_course_year.php">Course year</a>
                    <a href="new_course_taking.php">course taking</a>
                    <a href="new_room.php">room</a>
                    <a href="search.php">Search</a>

                    <?php
                } else {
                    ?>
                    <a href="new_streams.php">streams</a>
                    <a href="new_student_reg.php">student Registration</a>
                    <a href="new_academic_year.php">academic year</a>
                    <a href="new_course.php">course</a>
                    <a href="new_lecturer.php">lecturer</a>
                    <a href="new_lecturer_course.php">lecturer course</a>
                    <a href="new_course_taking.php">course taking</a>
                    <a href="new_room.php">room</a>
                    <a href="search.php">Search</a>  
                <?php } ?>

        </div>
    </div>
    <a href="new_time_table.php">timetable</a>
    <?php
        if ($_SESSION['cat'] == 'hod') {
            ?>
            <a href="new_student.php">student</a>
            <a href="../prints/print_time_table.php">Report</a>
            <?php
        }
    ?>

    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="../logout.php">Logout</a>
    </div>
</div>
