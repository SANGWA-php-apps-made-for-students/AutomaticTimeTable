<?php session_start(); ?>
<!DOCTYPE html>
<!--
Here is the admin dashboard
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
            require_once './admin_header.php';
        ?>
        <div class="parts eighty_centered no_paddin_shade_no_Border">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                <?php echo $_SESSION['cat'] . ' ';
                    echo $_SESSION['names']; ?>
            </div>
        </div>
    </body>
</html>
