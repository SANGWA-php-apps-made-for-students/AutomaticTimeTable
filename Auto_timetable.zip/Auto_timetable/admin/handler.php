<?php

    session_start();

    if (isset($_POST['cbo_account_category'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
        return $id;
    }
    
     
    
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_image'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
        return $id;
    }
    if (isset($_POST['cbo_year'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_year_id_by_year_name($_POST['cbo_year']);
        return $id;
    }
    if (isset($_POST['cbo_stream'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_stream_id_by_stream_name($_POST['cbo_stream']);
        return $id;
    }
    if (isset($_POST['cbo_student'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_student_id_by_student_name($_POST['cbo_student']);
        return $id;
    }
    if (isset($_POST['cbo_account'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
        return $id;
    }
    if (isset($_POST['cbo_lecturer'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_lecturer_id_by_lecturer_name($_POST['cbo_lecturer']);
        return $id;
    }
    if (isset($_POST['cbo_Course'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_Course_id_by_Course_name($_POST['cbo_Course']);
        return $id;
    }
    if (isset($_POST['cbo_time_table'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_time_table_id_by_time_table_name($_POST['cbo_time_table']);
        return $id;
    }
    if (isset($_POST['cbo_teaching_hour'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_teaching_hour_id_by_teaching_hour_name($_POST['cbo_teaching_hour']);
        return $id;
    }
    if (isset($_POST['cbo_teaching_day'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_teaching_day_id_by_teaching_day_name($_POST['cbo_teaching_day']);
        return $id;
    }
    if (isset($_POST['cbo_room'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_room_id_by_room_name($_POST['cbo_room']);
        return $id;
    }
    if (isset($_POST['cbo_academic_year'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_academic_year_id_by_academic_year_name($_POST['cbo_academic_year']);
        return $id;
    }
    if (isset($_POST['cbo_course'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_course_id_by_course_name($_POST['cbo_course']);
        return $id;
    }
    if (isset($_POST['cbo_account'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
        return $id;
    }

    if (isset($_POST['table_to_update'])) {
        $id_upd = $_POST['id_update'];
        $table_upd = $_POST['table_to_update'];
        $pref = 'upd_';
        $sufx = $table_upd;
        $_SESSION['table_to_update'] = $table_upd;
        $_SESSION['id_upd'] = $id_upd;
        echo $_SESSION['id_upd'];
    }


//The Delete from account
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account($id);
    }
//The Delete from account_category
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account_category($id);
    }
//The Delete from profile
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_profile($id);
    }
//The Delete from image
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_image($id);
    }
//The Delete from department
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'department') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_department($id);
    }
//The Delete from years
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'years') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_years($id);
    }
//The Delete from streams
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'streams') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_streams($id);
    }
//The Delete from student_reg
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'student_reg') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_student_reg($id);
    }
//The Delete from academic_year
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'academic_year') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_academic_year($id);
    }
//The Delete from course
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'course') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_course($id);
    }
//The Delete from lecturer
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'lecturer') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_lecturer($id);
    }
//The Delete from lecturer_course
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'lecturer_course') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_lecturer_course($id);
    }
//The Delete from teaching_hour
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'teaching_hour') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_teaching_hour($id);
    }
//The Delete from teaching_day
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'teaching_day') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_teaching_day($id);
    }
//The Delete from course_taking
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'course_taking') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_course_taking($id);
    }
//The Delete from room
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'room') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_room($id);
    }
//The Delete from time_table
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'time_table') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_time_table($id);
    }
//The Delete from student
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'student') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_student($id);
    }
    if (isset($_POST['pagination_n'])) {
        $_SESSION['pagination_n'] = $_POST['pagination_n'];
        $_SESSION['paginated_page'] = $_POST['paginated_page'];
        echo $_SESSION['paginated_page'];
    }
    if (isset($_POST['page_no_iteml'])) {
        unset($_SESSION['pagination_n']);
        $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
        $_SESSION['paginated_page'] = $_POST['paginated_page'];
        echo $_SESSION['page_no_iteml'];
    }

    if (filter_has_var(INPUT_POST, 'get_credits_left')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        echo $obj->get_credits_left_by_course_lec(filter_input(INPUT_POST, 'get_credits_left'));
    }
    if (filter_has_var(INPUT_POST, 'currently_assigned')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $year = filter_input(INPUT_POST, 'year');
        echo $obj->get_assigned_courses_by_year_ac(filter_input(INPUT_POST, 'currently_assigned'), filter_has_var(INPUT_POST, 'ac_year'));
    }
    if (filter_has_var(INPUT_POST, 'year_by_course')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        echo $obj->get_year_by_course(filter_input(INPUT_POST, 'year_by_course'));
    }
