<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_student_reg'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student_reg') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $student_reg_id = $_SESSION['id_upd'];
                $approved = $_POST['txt_approved'];
                $ac_year = $_POST['txt_ac_year'];
                $stream = $_POST['txt_stream_id'];
                $student = $_POST['txt_student_id'];
                $entry_date = date("y-m-d");
                $User = $_SESSION['userid'];
                $upd_obj->update_student_reg($approved, $ac_year, $stream, $student, $entry_date, $User, $student_reg_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $approved = 'yes'; ///$_POST['txt_approved'];
            $ac_year = $_POST['txt_cbo_ac_year_id'];
            $stream = trim($_POST['txt_stream_id']);
            $student = trim($_POST['txt_student_id']);
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];
            $m = new multi_values();
            $find = $m->get_student_already_registered($ac_year, $stream, $student);
            if (!empty($find)) {
                ?><script>alert('The student is already registred in the selected academic year, please choose a differenct one');</script><?php
            } else {
                require_once '../web_db/new_values.php';
                $obj = new new_values();
                $obj->new_student_reg($approved, $ac_year, $stream, $student, $entry_date, $User);
            }
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            student_reg</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_student_reg.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_stream_id"   name="txt_stream_id"/>
            <input type="hidden" id="txt_student_id"   name="txt_student_id"/>
            <input type="hidden"  id="txt_cbo_ac_year_id"   name="txt_cbo_ac_year_id"/>
            <?php
                include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                student_reg saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  student registration  </div>
                <table class="new_data_table">

                    <tr><td><label for="txt_ac_year">academic Year </label></td><td> 

                            <?php ac_year_combo(); ?>

                        </td></tr>
                    <tr><td class="new_data_tb_frst_cols">Stream </td><td> <?php get_stream_combo(); ?>  </td></tr> 
                    <tr><td class="new_data_tb_frst_cols">Student </td><td> <?php get_student_combo(); ?>  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_student_reg" value="Save"/>  </td></tr>
                </table>
            </div>


            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">student registration List</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_student_reg();
                    $obj->list_student_reg($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function ac_year_combo() {
        $obj = new multi_values();
        $obj->get_ac_year_in_combo();
    }

    function get_stream_combo() {
        $obj = new multi_values();
        $obj->get_stream_in_combo();
    }

    function get_student_combo() {
        $obj = new multi_values();
        $obj->get_student_in_combo();
    }

    function chosen_approved_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student_reg') {
                $id = $_SESSION['id_upd'];
                $approved = new multi_values();
                return $approved->get_chosen_student_reg_approved($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_ac_year_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student_reg') {
                $id = $_SESSION['id_upd'];
                $ac_year = new multi_values();
                return $ac_year->get_chosen_student_reg_ac_year($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_stream_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student_reg') {
                $id = $_SESSION['id_upd'];
                $stream = new multi_values();
                return $stream->get_chosen_student_reg_stream($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_student_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student_reg') {
                $id = $_SESSION['id_upd'];
                $student = new multi_values();
                return $student->get_chosen_student_reg_student($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student_reg') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_student_reg_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'student_reg') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_student_reg_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    