-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: automatic_timetable
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `academic_year`
--

DROP TABLE IF EXISTS `academic_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `academic_year` (
  `academic_year_id` int(11) NOT NULL AUTO_INCREMENT,
  `start_year` int(11) DEFAULT NULL,
  `end_year` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`academic_year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_year`
--

LOCK TABLES `academic_year` WRITE;
/*!40000 ALTER TABLE `academic_year` DISABLE KEYS */;
INSERT INTO `academic_year` VALUES (1,2017,'2018'),(2,2018,'2019'),(3,2016,'2017'),(4,2015,'2016'),(5,2014,'2015'),(6,2013,'2014');
/*!40000 ALTER TABLE `academic_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_category` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `is_online` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,3,'2018-01-01',1,'peter','123','yes'),(2,2,'2018-01-01',2,'paul','123','yes'),(11,2,'2018-07-06',6,'admin','1234','yes'),(12,2,'2018-07-06',7,'jules','123','yes'),(13,2,'2018-07-06',8,'prince','123','yes'),(15,2,'2018-07-16',10,'fred','123','yes'),(16,2,'2018-07-16',11,'frank','123','yes'),(17,2,'2018-07-16',12,'francois','123','yes'),(18,2,'2018-07-16',13,'admin','1234','yes'),(19,2,'2018-07-16',14,'admin','1234','yes'),(20,2,'2018-07-16',15,'admin','1234','yes'),(21,2,'2018-07-16',16,'admin','1234','yes'),(23,4,'2018-07-16',18,'Gerome','123','yes'),(24,4,'2018-07-16',19,'Samuel','123','yes'),(25,2,'2018-07-24',20,'MUCYO','MUCYO','yes'),(26,2,'2018-07-25',21,'kalisa','kalisa','yes'),(27,1,'2018-08-04',22,'CLAUDE','CLAUDE','yes'),(28,1,'2018-08-04',23,'cyiza','cyiza','yes'),(29,1,'2018-08-04',24,'AMAN','AMAN','yes'),(30,1,'2018-08-04',25,'karekezi','karekezi','yes'),(31,1,'2018-08-04',26,'UWERA','UWERA','yes'),(32,1,'2018-08-05',27,'yves','123','yes'),(33,4,'2018-08-07',28,'dieudonne','1234','yes'),(34,2,'2018-08-14',29,'fiacle','1234','yes');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_category`
--

DROP TABLE IF EXISTS `account_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_category` (
  `account_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`account_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_category`
--

LOCK TABLES `account_category` WRITE;
/*!40000 ALTER TABLE `account_category` DISABLE KEYS */;
INSERT INTO `account_category` VALUES (1,'lecturer'),(2,'student'),(3,'admin'),(4,'hod');
/*!40000 ALTER TABLE `account_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `no_credits` int(11) DEFAULT NULL,
  `code` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'Java',20,'ict2'),(2,'Web programming',20,'ict201'),(3,'Networking Fundamental',30,'ICT 301'),(4,'MATHEMATICS',30,'MATH 301');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_taking`
--

DROP TABLE IF EXISTS `course_taking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_taking` (
  `course_taking_id` int(11) NOT NULL AUTO_INCREMENT,
  `time_table` int(11) DEFAULT NULL,
  `is_techer_available` varchar(60) DEFAULT NULL,
  `tot_student_available` int(11) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`course_taking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_taking`
--

LOCK TABLES `course_taking` WRITE;
/*!40000 ALTER TABLE `course_taking` DISABLE KEYS */;
INSERT INTO `course_taking` VALUES (1,0,'yes',0,'habuze abanyeshuri babiri','2018-07-26','1');
/*!40000 ALTER TABLE `course_taking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_year`
--

DROP TABLE IF EXISTS `course_year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_year` (
  `course` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`course`,`year`),
  KEY `year` (`year`),
  CONSTRAINT `course_year_ibfk_1` FOREIGN KEY (`course`) REFERENCES `course` (`course_id`),
  CONSTRAINT `course_year_ibfk_2` FOREIGN KEY (`year`) REFERENCES `years` (`years_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_year`
--

LOCK TABLES `course_year` WRITE;
/*!40000 ALTER TABLE `course_year` DISABLE KEYS */;
INSERT INTO `course_year` VALUES (1,1),(3,1),(2,2),(4,2);
/*!40000 ALTER TABLE `course_year` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `account` int(11) NOT NULL,
  `hod` int(11) NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'ICT',23,0),(2,'DMP',24,0),(3,'WAS',0,0);
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lecturer`
--

DROP TABLE IF EXISTS `lecturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lecturer` (
  `lecturer_id` int(11) NOT NULL AUTO_INCREMENT,
  `edu_level` varchar(60) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  PRIMARY KEY (`lecturer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lecturer`
--

LOCK TABLES `lecturer` WRITE;
/*!40000 ALTER TABLE `lecturer` DISABLE KEYS */;
INSERT INTO `lecturer` VALUES (8,'A0',28),(9,'A0',29),(10,'Masters',30),(11,'A2',31),(12,'A0',32);
/*!40000 ALTER TABLE `lecturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lecturer_course`
--

DROP TABLE IF EXISTS `lecturer_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lecturer_course` (
  `lecturer_course_id` int(11) NOT NULL AUTO_INCREMENT,
  `lecturer` int(11) DEFAULT NULL,
  `Course` int(11) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`lecturer_course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lecturer_course`
--

LOCK TABLES `lecturer_course` WRITE;
/*!40000 ALTER TABLE `lecturer_course` DISABLE KEYS */;
INSERT INTO `lecturer_course` VALUES (6,8,2,'2018-08-04','1'),(7,9,1,'2018-08-04','1'),(8,10,3,'2018-08-04','1'),(9,11,4,'2018-08-04','1'),(10,12,2,'2018-08-05','32');
/*!40000 ALTER TABLE `lecturer_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `dob` date DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `telephone_number` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `residence` varchar(60) DEFAULT NULL,
  `image` int(11) DEFAULT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'1990-01-01','Peter','NGOGA','Male','07884746457','peter@gmail.com','Kimisagara',0),(2,'1989-01-01','Paul','RUGIRA','Male','07883473848','paul@gmail.com','Gatsata',0),(3,NULL,'Jules','alskjf','female',NULL,NULL,NULL,0),(4,NULL,'Jean Marie','alskjf','female',NULL,NULL,NULL,0),(5,NULL,'Francis','alskjf','female',NULL,NULL,NULL,0),(6,'2018-07-06','Micharel','aslkdj;f','male','','','',0),(7,'2018-07-06','Jules','NSENGIYUMVA','male','','','',0),(8,'2018-07-06','Prince','HABIMANA','male','','','',0),(9,'2018-07-06','Prince','HABIMANA','male','','','',0),(10,'2018-07-16','Fred','HABAGUHIRWA','male','','','',0),(11,'2018-07-16','Frank','NSANZABAGANWA','male','','','',0),(12,'2018-07-16','Francis','UJENEZA','male','','','',0),(13,'2018-07-16','sdfklj','aslkdf;j','male','','','',0),(14,'2018-07-16','sdfklj','aslkdf;j','male','','','',0),(15,'2018-07-16','sdfklj','aslkdf;j','male','','','',0),(16,'2018-07-16','asdflkjas','askljf;asf','male','','','',0),(17,'2018-07-16','FRANCOIS','HABIMANA','male','','','',0),(18,'2018-07-16','Gerome','MUNEZA','male','','','',0),(19,'2018-07-16','Samuel','HABIMANA','male','','','',0),(20,'2018-07-24','lambert','UMUVANDIMWE','male','','','',0),(21,'2018-07-25','kalisa','Aimable','male','','','',0),(22,'2018-08-04','Claude','NDAYAMBAJE','male','','','',0),(23,'2018-08-04','cyiza','cyiza','female','','','',0),(24,'2018-08-04','aman','fred','male','','','',0),(25,'2018-08-04','KAREKEZI','Michael','male','','','',0),(26,'2018-08-04','UWERA','Alice','female','','','',0),(27,'2018-08-05','Yves','MUHIRE','male','','','',0),(28,'2018-08-07','Dieudonne','MUSEMA','male','','','',0),(29,'2018-08-14','Fiacle','Emmanuel','male','','','',0);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (1,'ict-Room 1'),(2,'ict- Room2'),(3,'Mechanical R1'),(4,'Mechanical R2'),(5,'Electrical R1'),(6,'Electrical R2'),(7,'Multi media R1'),(8,'Multi media R2');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams`
--

DROP TABLE IF EXISTS `streams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams` (
  `streams_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  PRIMARY KEY (`streams_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams`
--

LOCK TABLES `streams` WRITE;
/*!40000 ALTER TABLE `streams` DISABLE KEYS */;
INSERT INTO `streams` VALUES (1,'A',1),(2,'B',1),(3,'C',1),(4,'A',2),(5,'B',2),(6,'C',2),(7,'A',3),(8,'B',3);
/*!40000 ALTER TABLE `streams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) DEFAULT NULL,
  `reg_number` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,10,'GS2016/0857'),(2,11,'GS2016/0746'),(5,34,'gs/2012/0174');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_reg`
--

DROP TABLE IF EXISTS `student_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_reg` (
  `student_reg_id` int(11) NOT NULL AUTO_INCREMENT,
  `approved` varchar(60) DEFAULT NULL,
  `ac_year` varchar(60) DEFAULT NULL,
  `stream` int(11) DEFAULT NULL,
  `student` int(11) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`student_reg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_reg`
--

LOCK TABLES `student_reg` WRITE;
/*!40000 ALTER TABLE `student_reg` DISABLE KEYS */;
INSERT INTO `student_reg` VALUES (1,'yes','2',2,1,'2018-07-16','1'),(2,'yes','2',4,2,'2018-07-16','1'),(3,'yes','5',7,4,'2018-07-16','1'),(4,'yes','3',3,3,'2018-07-17','1');
/*!40000 ALTER TABLE `student_reg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teaching_day`
--

DROP TABLE IF EXISTS `teaching_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teaching_day` (
  `teaching_day_id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(60) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`teaching_day_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaching_day`
--

LOCK TABLES `teaching_day` WRITE;
/*!40000 ALTER TABLE `teaching_day` DISABLE KEYS */;
INSERT INTO `teaching_day` VALUES (1,'Monday','2018-06-04','1'),(2,'Tuesday','2018-06-04','1'),(3,'Wednesday','2018-06-04','1'),(4,'Thursday','2018-07-11','1'),(5,'Friday','2018-07-16','1'),(6,'Saturday','2018-07-16','1'),(7,'Sunday','2018-07-16','1');
/*!40000 ALTER TABLE `teaching_day` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teaching_hour`
--

DROP TABLE IF EXISTS `teaching_hour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teaching_hour` (
  `teaching_hour_id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` varchar(60) DEFAULT NULL,
  `end_time` varchar(60) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`teaching_hour_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaching_hour`
--

LOCK TABLES `teaching_hour` WRITE;
/*!40000 ALTER TABLE `teaching_hour` DISABLE KEYS */;
INSERT INTO `teaching_hour` VALUES (1,'8h:00','8h:50','2018-06-04','1'),(2,'8h:50','9h:40','2018-07-11','1'),(3,'09h:00','10h:00','2018-07-16','1'),(4,'13h:00','14h:00','2018-07-16','1'),(5,'14h:00','15h:00','2018-07-16','1'),(6,'15h:00','16h:00','2018-07-16','1'),(7,'16h:00','17h:00','2018-07-16','1');
/*!40000 ALTER TABLE `teaching_hour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_table`
--

DROP TABLE IF EXISTS `time_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_table` (
  `time_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `teaching_hour` int(11) DEFAULT NULL,
  `teaching_day` int(11) DEFAULT NULL,
  `room` int(11) DEFAULT NULL,
  `academic_year` int(11) DEFAULT NULL,
  `course` int(11) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `User` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`time_table_id`),
  KEY `tt_day_idx` (`teaching_day`),
  KEY `tt_hour_idx` (`teaching_hour`),
  KEY `tt_room_idx` (`room`),
  KEY `tt_ac_year_idx` (`academic_year`),
  KEY `tt_course_idx` (`course`),
  CONSTRAINT `tt_ac_year` FOREIGN KEY (`academic_year`) REFERENCES `academic_year` (`academic_year_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `tt_day` FOREIGN KEY (`teaching_day`) REFERENCES `teaching_day` (`teaching_day_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `tt_hour` FOREIGN KEY (`teaching_hour`) REFERENCES `teaching_hour` (`teaching_hour_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tt_lecture_course` FOREIGN KEY (`course`) REFERENCES `lecturer_course` (`lecturer_course_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tt_room` FOREIGN KEY (`room`) REFERENCES `room` (`room_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_table`
--

LOCK TABLES `time_table` WRITE;
/*!40000 ALTER TABLE `time_table` DISABLE KEYS */;
INSERT INTO `time_table` VALUES (16,1,1,1,1,6,'2018-08-04','28'),(20,2,3,4,4,6,'2018-08-14','33'),(21,1,1,3,3,10,'2018-08-05','32'),(22,1,3,3,5,8,'2018-08-14','33'),(24,4,1,1,2,6,'2018-08-14','33'),(27,2,3,7,3,6,'2018-08-14','33'),(32,6,7,8,5,8,'2018-08-14','33'),(35,5,2,1,1,6,'2018-08-13','33');
/*!40000 ALTER TABLE `time_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `years`
--

DROP TABLE IF EXISTS `years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `years` (
  `years_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  PRIMARY KEY (`years_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `years`
--

LOCK TABLES `years` WRITE;
/*!40000 ALTER TABLE `years` DISABLE KEYS */;
INSERT INTO `years` VALUES (1,'Year 1',NULL),(2,'Year 2',NULL),(3,'Year 3',NULL);
/*!40000 ALTER TABLE `years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'automatic_timetable'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-15 13:48:49
