<div class="parts  eighty_centered no_paddin_shade_no_Border">          
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        Automatic Timetable
    </div>
</div>   
<div class="parts menu eighty_centered no_paddin_shade_no_Border">
    <a href="index.php">Home</a>
    <a href="#">About us</a>
    <a href="new_profile.php">profile</a>

    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border off">
        <a href="login.php">Login</a>
    </div>
</div>
