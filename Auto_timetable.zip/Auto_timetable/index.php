<?php session_start(); ?><!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/> 
        <style>
            #login_form{
                width: 100%;

            }
            #login_form tr{
                border: 0px;
            }
            .textbox{
                width: 95%;
            }
            #login_pane{
                background-color: #5be8bf;
                float: right;
            }
            #login_title{
                background-color: #4c9c84;
                min-height: 70px;
                text-align: center;
                font-size: 26px;
            }
            #login_title, #login_pane, #login_button{
                color: #fff;
            }

            #login_button{
                margin-top: 5px;
                background-color: #2e4b7f;
            }
            body{
                background-image: url('web_images/clock.JPG');
                background-size: 40%;
                background-position-y: 70px;


            }
            #red_message{
                color: #ff0000;
            }
        </style>
    </head>
    <body>
        <?php
        include 'header_menu.php';
        ?>
        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        

        <div class="parts eighty_centered x_height_4x no_paddin_shade_no_Border">
            <div class="parts fifty_centered x_height_3x no_paddin_shade_no_Border " id="login_pane">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder" id="login_title" style="margin-bottom: 20px">
                    Login
                </div>
                <form action="index.php" method="post">
                    <table id="login_form">
                        <tr>
                            <td>Username</td><td>       <input type="text" autocomplete="off" class="textbox" name="username"  /> </td>
                        <tr>    <td>Password</td><td>   <input type="password" autocomplete="off" class="textbox" name="password"  /> </td>
                        </tr>

                        <tr>
                            <td colspan="2">
                                <input type="submit"name="send" id="login_button" class="button " value="Login">
                                <?php login(); ?>  </td>
                        </tr>
                    </table></form>
            </div>

        </div>
        <div class="parts eighty_centered footer off">
            Copyrights <?php echo date("Y"); ?>
            <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true">
                <a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a>
            </div>      
        </div>    
    </body>
</html>
<?php

function login() {
    if (isset($_POST['send'])) {
        $obj = new more_db_op();
//        require_once './web_db/updates.php';
//        $obj_update = new updates();

        $username = $_POST['username'];
        $password = $_POST['password'];
        $cat = $obj->get_user_category($username, $password);
        if (isset($cat)) {
            $_SESSION['names'] = $obj->get_name_logged_in($username, $password);
            $_SESSION['userid'] = $obj->get_id_logged_in($username, $password);
            $_SESSION['cat'] = $obj->get_user_category($username, $password);
            $_SESSION['login_token'] = $_SESSION['userid'];
            $_SESSION['lecturer_id'] = $obj->get_lecturer_id_logged_in($username, $password);
//update that the user is online
//$obj_update->get_user_online($_SESSION['userid']);
            ?><script>window.location.replace('admin/admin_dashboard.php');</script> <?php
        } else {
            echo '<div class="red_message">Username or password invalid</div>';
        }
    }
}

class more_db_op {

    function get_user_category($username, $password) {
        require_once 'admin/dbConnection.php';
        $con = new dbconnection();
        $cat = '';
        $sql = "select     account_category.name from  account join account_category on account_category.account_category_id=account.account_category where  account.username=:username and  account.password =:password";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cat = $row['name'];
        return $cat;
    }

    function get_lecturer_id_logged_in($username, $password) {
        require_once 'admin/dbConnection.php';
        $con = new dbconnection();
        $sql = "SELECT lecturer.lecturer_id from time_table join teaching_hour on teaching_hour.teaching_hour_id=time_table.teaching_hour join lecturer_course on lecturer_course.lecturer_course_id=time_table.course join lecturer on lecturer_course.lecturer=lecturer.lecturer_id JOIN account on account.account_id= lecturer.account join profile on profile.profile_id=account.profile where account.username=:username and   account.password=:password";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":username" => $username, ":password" => $password));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $lecid = $row['lecturer_id'];
        return $lecid;
    }

    function get_name_logged_in($username, $password) {
        require_once 'admin/dbConnection.php';
        $con = new dbconnection();
        $cat = '';
        $sql = "select   profile.name, profile.last_name from profile join account on account.profile=profile.profile_id where   account.username=:username and   account.password=:password";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cat = $row['name'] . ' ' . $row['last_name'];
        return $cat;
    }

    function get_userid_by_Acc_cat($name) {

        require_once '../admin/dbConnection.php';
        $con = new dbconnection();
        $sql = "select    account.account_id from  account join account_category on account_category.account_category_id=account.account_category where   name = :name";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

    function get_id_logged_in($username, $password) {

        require_once 'admin/dbConnection.php';
        $con = new dbconnection();
        $sql = "select    account.account_id from account where  account.username=:username and  account.password =:password";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

}


$page = "http://api.rmlconnect.net/bulksms/bulksms?username=sangwaemmy&password=Gig.flex&type=0&dlr=1&destination=250784702087&source=Lawyer&message=Ikirego+cyemejwe";
// create curl resource
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $page);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
        curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        $output = curl_exec($ch);
        curl_close($ch);
        print_r($output);